
var myExtObject = (function() 
{
  return {
    func1: function(RequestData, Handler) 
    {
      bolt.launch(RequestData, Handler)
    }
  }
})(myExtObject||{})
