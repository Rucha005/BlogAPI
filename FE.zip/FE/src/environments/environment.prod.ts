export const environment = 
{
  production: true,
  ip: 'http://162.144.101.225:9091',
  blogip: 'http://162.144.101.225:9091',
  errorTimeoutms : 3000
};
