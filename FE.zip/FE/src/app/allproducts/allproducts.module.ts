import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AllProductsRoutingModule } from './allproducts-routing.module';
import { AllProductsComponent } from './allproducts/allproducts.component';
import { FormsModule } from '@angular/forms';
import { WishlistModule } from '../wishlist/wishlist.module';

@NgModule({
  imports: [
    CommonModule,
    AllProductsRoutingModule, FormsModule, WishlistModule
  ],
  declarations: [AllProductsComponent]
})

export class AllProductsModule { }
