import { Component, OnInit } from '@angular/core';
import { ContactUsService } from './contactus.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { environment } from '../../../environments/environment';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {
  errormessage: string;
  successmessage: string;
  contactForm: FormGroup;
  name: string;

  constructor(private mailService: ContactUsService,private fb: FormBuilder,private spinnerService: Ng4LoadingSpinnerService) 
  {
    this.contactForm = this.fb.group({
      'name':['',Validators.required],
      'emailId':['',Validators.required],
      'mobileNumber':['',Validators.required],
      'subject':[''],
      'message':['',Validators.required],
     })
  }

  ngOnInit() {}
  
  sendEmail() 
  {
    let data = (JSON.stringify(this.contactForm.value));
    let customername = this.name
    if(this.contactForm.controls['name'].valid && this.contactForm.controls['emailId'].valid && this.contactForm.controls['mobileNumber'].valid && this.contactForm.controls['message'].valid )
    {
      this.spinnerService.show();
      this.mailService.sendmailContactUs(this.contactForm.value).subscribe(res => 
      {
        this.spinnerService.hide();
        this.successmessage = "Your message has been send";
        this.contactForm.reset();
      },
      (error) => 
      {
        this.spinnerService.hide();
        this.errormessage = "Sorry " + customername + ", it seems that my mail server is not responding. Please try again later";
      })
    }
    else
    {
      this.errormessage = "Please fill in all required fields"
      this.remove();
    }  
  }

  remove()
  {
    setTimeout(function() 
    {
      this.errormessage = null;
    }.bind(this), environment.errorTimeoutms);
  }
}
