import { ContactusComponent } from './contactus/contactus.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactUsService } from './contactus/contactus.service';

const routes: Routes = [
  {
    path: '',
    component: ContactusComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  providers:[ContactUsService],
  exports: [RouterModule]
})
export class ContactusRoutingModule { }
