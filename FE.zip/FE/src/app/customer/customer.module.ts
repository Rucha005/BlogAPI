import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CustomerRoutingModule } from './customer-routing.module';
import { CustomerComponent } from './customer/customer.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MyDatePickerModule } from 'mydatepicker';



@NgModule({
  imports: [
    CommonModule,
    CustomerRoutingModule, ReactiveFormsModule, MyDatePickerModule
  ],
  declarations: [CustomerComponent]
})
export class CustomerModule { }
