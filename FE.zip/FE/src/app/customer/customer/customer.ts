export class Customer {
	constructor( public userId: number,
				 public username :string,
        		 public password : string,
				 public accountName:string,
				 public profilePic : string,
				 public recoveryMobile : string,
				 public recoveryEmail : string,
				 public facebookProfile: string,
                 public googleSignIn: string,
                 public accountStatus: string,
                 public deactivationStatus: string,
				 public userRoleMaster: userRoleData				
       		   ) { }
} 
export class userRoleData {
	constructor( public roleId: number,
		         public roleName: string,
	             public roleDescription: string,
	             public roleLogo: string,
                 public userPersonalDetails: userPersonalData[]	    
	           ){}   
}
export class userPersonalData {
	constructor( public userPersonalId: number,
		         public firstName: string,
	             public lastName: string,
	             public dateOfBirth: string,
	             public gender: string,
                 public communicationDetails: communicationData[]	    
	           ){}    
}
export class communicationData {
	constructor( public communicationDetailsId: number,
		         public mobileNoForSMS: string,
		         public emailForCommunication: string, 
	             public alternateMobileNo: string,
	             public alternateEmailId: string,
	             public subscriptions: string,
                 //public addressDetails: addressData[]
	           ){}  
}
export class legalRegistrationData {
	constructor( public legalRegiNumberId: number,
		         public docNumber: string,
                 public docScan: string,
                 public docType: string,
                 public verificationStatus: string,
                 public remark: string
	           ){}
}