import { DatePipe } from '@angular/common';
import { LOCAL_STORAGE } from '@ng-toolkit/universal';
import { Component, OnInit , Inject} from '@angular/core';
import { FormGroup, FormBuilder,Validators,FormArray} from '@angular/forms';
import { ActivatedRoute, Router} from '@angular/router';
import { JwtHelperService} from '@auth0/angular-jwt';
import { IMyOptions} from 'mydatepicker';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ErrorStatus } from '../../common/ErrorStatus';
import { RegistartionService } from '../../common/registartion.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})

export class CustomerComponent implements OnInit 
{
  pattern: string;
  customerDocument:Array<File> = [];
  errorStatus: ErrorStatus;
  customerErrorMessage = null;
  customerSuccessMessage = null;
  dob: any;
  registerForm: FormGroup;
  doctype:any;
 
  constructor(@Inject(LOCAL_STORAGE) private localStorage: any, private spinnerService: Ng4LoadingSpinnerService,private datePipe: DatePipe,
    private fb: FormBuilder,private router: Router,private route:ActivatedRoute, private service: RegistartionService) 
  {
    if(this.isLoggedIn())
      this.router.navigate(['/home'])   
    
      this.registerForm = this.fb.group(
      {
       'userId': [null, Validators.required],
       'username': ['', Validators.required],
       'password': ['', Validators.required],
       'accountName': ['', Validators.required],
       'profilePic': ['', Validators.required],
       'recoveryMobile': ['', [Validators.required,Validators.minLength(10),Validators.maxLength(10)]],
       'recoveryEmail': ['', Validators.required],
       'facebookProfile': ['NA', Validators.required],
       'googleSignIn': ['NA', Validators.required],
       'accountStatus': ['', Validators.required],
       'deactivationStatus': ['', Validators.required],
       userRoleMaster:this.fb.group(
       {
        'roleId': [null, Validators.required],
        'roleName': ['', Validators.required],
        'roleDescription': ['', Validators.required],
        'roleLogo': ['', Validators.required]
       }),
       userPersonalDetails: this.fb.array([
        this.fb.group(
        {
          'userPersonalId': [null, Validators.required],
          'firstName': ['', [Validators.required,Validators.minLength(3),Validators.maxLength(30)]],
          'lastName': ['', [Validators.required,Validators.minLength(3),Validators.maxLength(30)]],
          'dateOfBirth': ['', Validators.required],
          'gender': ['', Validators.required]
        })
       ]),
       communicationDetails: this.fb.array([
        this.fb.group(
        {
          'communicationDetailsId': [null, Validators.required],
          'mobileNoForSMS': ['', [Validators.required,Validators.minLength(10),Validators.maxLength(10)]],
          'emailForCommunication': ['', [Validators.required]],
        })
       ]),
       legalRegistrationNumbers: this.fb.array([
        this.fb.group(
        {
          'legalRegiNumberId': [null, Validators.required],
          'docNumber': ['',Validators.required],
          'docScan': ['', Validators.required],
          'docType': ['', Validators.required],
          'verificationStatus': ['', Validators.required],
          'remark': ['', Validators.required]
        })
       ]),             
      });
  }

  ngOnInit() {}
  
  get legalRegistrationNumbers()
  {
    return (<FormArray>this.registerForm.controls['legalRegistrationNumbers']).controls
  }

  get userPersonalDetails()
  {
    return (<FormArray>this.registerForm.controls['userPersonalDetails']).controls
  }

  get communicationDetails()
  {
    return (<FormArray>this.registerForm.controls['communicationDetails']).controls
  }

  /** Check already customer is logged in or not then navigate */
  isLoggedIn() 
  {
    if(this.localStorage.getItem('currentUser'))
    {
      const currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
      if (currentUser) 
      {
        let token = currentUser && currentUser.token;
        if (token) 
        {
          let jwtHelper = new JwtHelperService();
          let expirationDate = jwtHelper.getTokenExpirationDate(token);
          let isExpired = jwtHelper.isTokenExpired(token);
          if ( ! isExpired) 
          {
            return true;
          }
        }
      }
    }
    return false;
  }

  private dateChanged: IMyOptions;
  public DateChanged(selectedDate)
  {
      this.dateChanged=
      {
        dateFormat: 'yyyy-MM-dd',
      };
      this.dob = this.datePipe.transform(selectedDate.jsdate, 'yyyy-MM-dd');
  }

  /** register customer */
  submitPost()
  {     
      (<FormArray>(<FormGroup>this.registerForm).controls['legalRegistrationNumbers']).at(0).get('docType').setValue(this.doctype);
      (<FormArray>(<FormGroup>this.registerForm).controls['userPersonalDetails']).at(0).get('dateOfBirth').setValue(this.dob);
      (<FormArray>(<FormGroup>this.registerForm).controls['communicationDetails']).at(0).get('emailForCommunication').setValue(this.registerForm.value.username);
      const formData: any = new FormData();
      const customerDocument: File = this.customerDocument[0];
      if(customerDocument)
      {
        formData.append("customerDocument", customerDocument, customerDocument.name);
        formData.append('userLogins',new Blob([JSON.stringify(this.registerForm.value)],
        {
          type: "application/json"
        }));
      }
      else
      {
        formData.append('userLogins',new Blob([JSON.stringify(this.registerForm.value)],
        {
          type: "application/json"
        }));
      }
      
      if(this.registerForm.controls['username'].valid && 
         this.registerForm.controls['password'].valid &&
         (<FormArray>(<FormGroup>this.registerForm).controls['userPersonalDetails']).at(0).get('firstName').valid && 
         (<FormArray>(<FormGroup>this.registerForm).controls['userPersonalDetails']).at(0).get('lastName').valid &&
         (<FormArray>(<FormGroup>this.registerForm).controls['communicationDetails']).at(0).get('mobileNoForSMS').valid )
      {
          this.spinnerService.show();
          this.service.registerCust(formData)
            .subscribe(response => 
            {
                this.spinnerService.hide();
                this.customerSuccessMessage = "Thank you for registering on Voyagekart!! Login with your new credentials."
            },
            (error)=>
            {
                this.spinnerService.hide();
                this.errorStatus = JSON.parse(error._body);
                if (this.errorStatus) 
                {
                  this.customerErrorMessage =  this.errorStatus.errorMessage
                  this.removeErrorMessage() 
                }
            }); 
      }
      else
      {
            this.customerErrorMessage =  "Please fill in all required fields"
            this.removeErrorMessage() 
      }
  }

  /** get value for selected document type (aadhar,pan etc)*/
  documenttype(value) 
  {
    this.doctype = null;
    this.doctype = value;
  }

  /** get selected file */
  fileChangeEvent(fileInput)
  {
    this.customerDocument = fileInput.target.files;
  }

  /** remove error message after 5 seconds */
  removeErrorMessage() 
  {
    setTimeout(function() 
    {
      this.customerErrorMessage = null;
      this.customerSuccessMessage = null;
    }.bind(this), environment.errorTimeoutms);
  }
}
