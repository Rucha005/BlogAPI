import { OrderCancellationModule } from './order-cancellation.module';

describe('OrderCancellationModule', () => {
  let orderCancellationModule: OrderCancellationModule;

  beforeEach(() => {
    orderCancellationModule = new OrderCancellationModule();
  });

  it('should create an instance', () => {
    expect(orderCancellationModule).toBeTruthy();
  });
});
