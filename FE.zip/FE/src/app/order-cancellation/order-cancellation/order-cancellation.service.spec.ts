import { TestBed, inject } from '@angular/core/testing';

import { OrderCancellationService } from './order-cancellation.service';

describe('OrderCancellationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OrderCancellationService]
    });
  });

  it('should be created', inject([OrderCancellationService], (service: OrderCancellationService) => {
    expect(service).toBeTruthy();
  }));
});
