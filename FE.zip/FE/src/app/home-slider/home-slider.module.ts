import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeSliderRoutingModule } from './home-slider-routing.module';
import { HomeSliderComponent } from './home-slider/home-slider.component';

@NgModule({
  imports: [
    CommonModule,
    HomeSliderRoutingModule
  ],
  declarations: [HomeSliderComponent],
  exports:[HomeSliderComponent]
})
export class HomeSliderModule { }
