import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MyaccountRoutingModule } from './myaccount-routing.module';
import { MyAccountComponent } from './myaccount/myaccount.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RatingModule } from '../rating/rating.module';
import { MyProductReviewModule } from '../my-product-review/my-product-review.module';
import { WishlistModule } from '../wishlist/wishlist.module';
import { MywishlistModule } from '../mywishlist/mywishlist.module';
import { OrderCancellationModule } from '../order-cancellation/order-cancellation.module';
import { AddressService } from '../common/address.service';
import { AllServices } from '../common/allservices.services';

@NgModule({
  imports: [
    CommonModule,
    MyaccountRoutingModule, ReactiveFormsModule, FormsModule, RatingModule, 
    MyProductReviewModule, MywishlistModule, OrderCancellationModule
  ],
  declarations: [MyAccountComponent],
  providers:[AddressService,AllServices]
})
export class MyAccountModule { }
