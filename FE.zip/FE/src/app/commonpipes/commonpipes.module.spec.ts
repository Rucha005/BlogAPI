import { CommonpipesModule } from './commonpipes.module';

describe('CommonpipesModule', () => {
  let commonpipesModule: CommonpipesModule;

  beforeEach(() => {
    commonpipesModule = new CommonpipesModule();
  });

  it('should create an instance', () => {
    expect(commonpipesModule).toBeTruthy();
  });
});
