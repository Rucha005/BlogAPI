import { ViewCartModule } from './view-cart.module';

describe('ViewCartModule', () => {
  let viewCartModule: ViewCartModule;

  beforeEach(() => {
    viewCartModule = new ViewCartModule();
  });

  it('should create an instance', () => {
    expect(viewCartModule).toBeTruthy();
  });
});
