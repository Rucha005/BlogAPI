import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { ViewCartRoutingModule } from './view-cart-routing.module';
import { ViewCartComponent } from './view-cart/view-cart.component';
import { WishlistModule } from '../wishlist/wishlist.module';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../common/product.service';
import { ProductCartService } from '../common/product-cart.service';
import { RegistartionService } from '../common/registartion.service';
import { AllServices } from '../common/allservices.services';
import { LoginService } from '../login/login/login.service';

@NgModule({
  imports: [
    CommonModule,
    ViewCartRoutingModule, WishlistModule, FormsModule
  ],
  declarations: [ViewCartComponent],
  providers:[DatePipe,
    ProductService,ProductCartService,RegistartionService,AllServices,LoginService]
})
export class ViewCartModule { }
