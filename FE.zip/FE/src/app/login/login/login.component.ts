import { LOCAL_STORAGE } from '@ng-toolkit/universal';
import { Component, OnInit, Inject } from '@angular/core';
import { LoginService } from './login.service';
import { Login } from './login';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { ErrorStatus } from '../../common/ErrorStatus';
import { environment } from '../../../environments/environment';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FormBuilder, Validators, FormArray, FormGroup, FormControl } from '@angular/forms';
import { RegistartionService } from '../../common/registartion.service';
import { GetOtpResponse } from '../../forgot-password/forgot-password/get-otp-response';
import { VerifyOTP } from '../../forgot-password/forgot-password/verify-otp';
import { JwtHelperService } from '@auth0/angular-jwt';
import { ForgotUsernameService } from '../../forgot-username/forgot-username/forgot-username.service';
import { PasswordValidators } from '../../forgot-password/forgot-password/password-validators';
import { ForgotPasswordService } from '../../forgot-password/forgot-password/forgot-password.service';
import { ProductCartService } from '../../common/product-cart.service';
import { Products } from '../../products/products/products';
import { HeaderComponent } from '../../header/header/header.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  getparam: any;
  href: string;
  email: string;
  invalidLogin: boolean;
  role: string;
  customerErrorMessage = null;
  customerSuccessMessage = null;
  customerregistrationErrorMessage = null;
  errorStatus: ErrorStatus;
  loginForm: FormGroup;

  customerregister: boolean = false;
  forgotpassword: boolean = false;
  forgotusername: boolean = false;

  /** customer registration */
  registerForm: FormGroup;

  /** forgot username / password */

  responseForRequestOtp: GetOtpResponse;
  responseForVerifyOtp: VerifyOTP;
  responseForCreateNewPasswordOtp;
  displayFormRequestOtp = "none";
  displayFormVerifyOtp = "none";
  displayFormCreatePassword = "none";
  displayButtonFormVerifyOtpSubmit = true;
  emailOptionChecked: boolean;
  smsOptionChecked: boolean;
  displayButtonResendOtp = false;
  formerror = true;
  incorrectOtp = false;
  userDoesNotExist :any;
  errormessage = null;
  logincustomerErrorMessage: string;
  submitotploginbtn: boolean = false;
  showotptext: boolean = false;
  showmobnologin: boolean = true;
  getotploginbtn: boolean = true;

  items: Products[] = [];
  cart_form: FormArray;
  cartError: string;
  customerId: any;
  disabledValue: boolean;
  passwordSuccessMessage: string;
  loginotp: any;
  loginviaotpdata: any;
  loginmobilenumber: any;
  loginotpdata: any;




  constructor(@Inject(LOCAL_STORAGE) private localStorage: any, private loginService: LoginService, private service: ForgotPasswordService,
    private router: Router, private route: ActivatedRoute, private spinnerService: Ng4LoadingSpinnerService, private forgotUserservice: ForgotUsernameService,
    private _location: Location, private fb: FormBuilder, private customeService: RegistartionService, private cartService: ProductCartService) {
    localStorage.removeItem('currentUser');
    this.registerForm = this.fb.group(
      {
        'userId': [null, Validators.required],
        'username': ['', Validators.required],
        'password': ['', Validators.required],
        'accountName': ['', Validators.required],
        'profilePic': ['', Validators.required],
        'recoveryMobile': ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
        'recoveryEmail': ['', Validators.required],
        'facebookProfile': ['NA', Validators.required],
        'googleSignIn': ['NA', Validators.required],
        'accountStatus': ['', Validators.required],
        'deactivationStatus': ['', Validators.required],
        userRoleMaster: this.fb.group(
          {
            'roleId': [null, Validators.required],
            'roleName': ['', Validators.required],
            'roleDescription': ['', Validators.required],
            'roleLogo': ['', Validators.required]
          }),
        // userPersonalDetails: this.fb.array([
        //   this.fb.group(
        //     {
        //       'userPersonalId': [null, Validators.required],
        //       'firstName': ['', [Validators.required, Validators.minLength(3), Validators.maxLength(30)]],
        //       'lastName': ['', [Validators.required, Validators.minLength(3), Validators.maxLength(30)]],
        //       'dateOfBirth': ['', Validators.required],
        //       'gender': ['', Validators.required]
        //     })
        // ]),
        communicationDetails: this.fb.array([
          this.fb.group(
            {
              'communicationDetailsId': [null, Validators.required],
              'mobileNoForSMS': ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
              'emailForCommunication': ['', [Validators.required]],
            })
        ]),
        legalRegistrationNumbers: this.fb.array([
          this.fb.group(
            {
              'legalRegiNumberId': [null, Validators.required],
              'docNumber': ['', Validators.required],
              'docScan': ['', Validators.required],
              'docType': ['', Validators.required],
              'verificationStatus': ['', Validators.required],
              'remark': ['', Validators.required]
            })
        ]),
      });

  }

  ngOnInit() {
    this.route.paramMap.subscribe(
      params => {
        this.email = params.get('email');
      }
    );
    this.cart_form = this.fb.array([]);

  }


  login(loginData: Login) {
    this.logincustomerErrorMessage = null;
    this.customerErrorMessage = null;
    this.customerSuccessMessage = null;
    this.customerregistrationErrorMessage = null;
    if (loginData.email === 'adminblog@gmail.com' && loginData.password === 'Admin@123') {
      this.spinnerService.show();
      this.loginService.login(loginData.email, loginData.password)
        .subscribe((result) => {
          this.spinnerService.hide();
          if (result) {
            if (this.localStorage.getItem('currentUser')) {
              var currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
              location.reload();
              this.router.navigate(['/blogs/']);
            }
          }
        },
          (error) => {
            this.spinnerService.hide();
            this.errorStatus = JSON.parse(error._body);
            if (this.errorStatus.status) {
              this.logincustomerErrorMessage = "Username or Password may be incorrect.";
              this.removeErrorMessage();
              this.invalidLogin = true;
            }
          });
    }
    else {
      this.spinnerService.show();
      this.loginService.login(loginData.email, loginData.password)
        .subscribe((result) => {
          this.spinnerService.hide();
          if (result) {
            if (this.localStorage.getItem('currentUser')) {
              var currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
              this.role = currentUser.role;
              if (this.role.includes("ROLE_USER")) {
                this.customerSuccessMessage = "You are login successfully!!"
                this.removeErrorMessage()
                this.href = document.referrer;
                this.getparam = this.href.substr(this.href.lastIndexOf('/') + 1);
                //debugger
                if (this.localStorage.getItem('proceed-checkoutflag') == 'true') {
                  if (this.localStorage.getItem('currentUser')) {
                    var currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
                    if (currentUser) {
                      this.spinnerService.show();
                      this.customeService.getByUsername(currentUser.username)
                        .subscribe(items => {
                          this.spinnerService.hide();
                          this.customerId = items.userId
                          this.addLocalCartDataToDatabase();
                          this.loadAllCartDataByCustomerId();
                        },
                          (error) => {
                            this.spinnerService.hide();
                          });
                    }
                  }
                  if (this.cartService.checkLocalStroageIsEmpty() == false) {
                    if (this.localStorage.getItem('cartData')) {
                      this.items = JSON.parse(this.localStorage.getItem('cartData'))
                      for (let i = 0; i < this.items.length; i++) {
                        if (this.items[i].rentCartItemOffers == null) {
                          this.cart_form.push(
                            this.initForm(
                              this.items[i].rentTransactionId,
                              this.items[i].modelId,
                              this.items[i].rentPerDay,
                              (this.items[i].rentPerDay),
                              this.items[i].productQuantity,
                              this.items[i].bookingFromDate,
                              this.items[i].bookingToDate,
                              this.items[i].cartType,
                              ((this.items[i].rentPerDay) * this.items[i].days), 0))
                        }
                        else {
                          if (this.items[i].rentCartItemOffers.length > 0) {
                            this.cart_form.push(
                              this.initForm(
                                this.items[i].rentTransactionId,
                                this.items[i].modelId,
                                this.items[i].rentPerDay,
                                (this.items[i].rentPerDay - (this.items[i].rentPerDay * this.items[i].rentCartItemOffers[0].percentageOffer / 100)),
                                this.items[i].productQuantity,
                                this.items[i].bookingFromDate,
                                this.items[i].bookingToDate,
                                this.items[i].cartType,
                                ((this.items[i].rentPerDay - (this.items[i].rentPerDay * this.items[i].rentCartItemOffers[0].percentageOffer / 100)) * this.items[i].days),
                                this.items[i].rentCartItemOffers[0].offerId))
                          }
                          else {
                            this.cart_form.push(
                              this.initForm(
                                this.items[i].rentTransactionId,
                                this.items[i].modelId,
                                this.items[i].rentPerDay,
                                (this.items[i].rentPerDay),
                                this.items[i].productQuantity,
                                this.items[i].bookingFromDate,
                                this.items[i].bookingToDate,
                                this.items[i].cartType,
                                ((this.items[i].rentPerDay) * this.items[i].days), 0))
                          }
                        }
                      }

                      this.spinnerService.show();
                      this.cartService.addCartDataToDatabase(this.cart_form.value)
                        .subscribe(response => {
                          this.spinnerService.hide();
                          this.localStorage.removeItem('cartData')
                          //this.loadAllCartDataByCustomerId();
                        },
                          (error) => {
                            this.spinnerService.hide();
                          });
                    }
                  }
                }
                else if (this.getparam == 'login' || this.getparam == '') {
                  this.router.navigate(['/home/']);
                }
                else {
                  location.reload();
                  this._location.back();
                }
              }
            }
          }
        },
          (error) => {
            this.spinnerService.hide();
            this.errorStatus = JSON.parse(error._body);
            if (this.errorStatus.status) {
              this.logincustomerErrorMessage = "Username or Password may be incorrect.";
              this.removeErrorMessage();
              this.invalidLogin = true;
            }
          });
    }
  }

  /* get user name and and load all cart data */
  getByUsername() {
    if (this.localStorage.getItem('currentUser')) {
      var currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
      if (currentUser) {
        this.spinnerService.show();
        this.customeService.getByUsername(currentUser.username)
          .subscribe(items => {
            this.spinnerService.hide();
            this.customerId = items.userId
            this.addLocalCartDataToDatabase();
            this.loadAllCartDataByCustomerId();
          },
            (error) => {
              this.spinnerService.hide();
            });
      }
    }
  }

  /* add local data to database */
  addLocalCartDataToDatabase() {
    if (this.cartService.checkLocalStroageIsEmpty() == false) {
      if (this.localStorage.getItem('cartData')) {
        this.items = JSON.parse(this.localStorage.getItem('cartData'))
        for (let i = 0; i < this.items.length; i++) {
          if (this.items[i].rentCartItemOffers == null) {
            this.cart_form.push(
              this.initForm(
                this.items[i].rentTransactionId,
                this.items[i].modelId,
                this.items[i].rentPerDay,
                (this.items[i].rentPerDay),
                this.items[i].productQuantity,
                this.items[i].bookingFromDate,
                this.items[i].bookingToDate,
                this.items[i].cartType,
                ((this.items[i].rentPerDay) * this.items[i].days), 0))
          }
          else {
            if (this.items[i].rentCartItemOffers.length > 0) {
              this.cart_form.push(
                this.initForm(
                  this.items[i].rentTransactionId,
                  this.items[i].modelId,
                  this.items[i].rentPerDay,
                  (this.items[i].rentPerDay - (this.items[i].rentPerDay * this.items[i].rentCartItemOffers[0].percentageOffer / 100)),
                  this.items[i].productQuantity,
                  this.items[i].bookingFromDate,
                  this.items[i].bookingToDate,
                  this.items[i].cartType,
                  ((this.items[i].rentPerDay - (this.items[i].rentPerDay * this.items[i].rentCartItemOffers[0].percentageOffer / 100)) * this.items[i].days),
                  this.items[i].rentCartItemOffers[0].offerId))
            }
            else {
              this.cart_form.push(
                this.initForm(
                  this.items[i].rentTransactionId,
                  this.items[i].modelId,
                  this.items[i].rentPerDay,
                  (this.items[i].rentPerDay),
                  this.items[i].productQuantity,
                  this.items[i].bookingFromDate,
                  this.items[i].bookingToDate,
                  this.items[i].cartType,
                  ((this.items[i].rentPerDay) * this.items[i].days), 0))
            }
          }
        }

        this.spinnerService.show();
        this.cartService.addCartDataToDatabase(this.cart_form.value)
          .subscribe(response => {
            this.spinnerService.hide();
            this.localStorage.removeItem('cartData')
            this.loadAllCartDataByCustomerId();
          },
            (error) => {
              this.spinnerService.hide();
            });
      }
    }
  }
  initForm(rentTransactionId, modelId, rentPerDay, rentAfterOffer, productQuantity, bookingFromDate, bookingToDate, cartType, totalRent, offerId) {
    return this.fb.group({
      'cartId': [null],
      'customerId': [this.customerId],
      'rentTransactionId': [rentTransactionId],
      'modelId': [modelId],
      'rentPerDay': [rentPerDay],
      'rentAfterOffer': [rentAfterOffer],
      'productQuantity': [productQuantity],
      'deliveryPinCode': [411030],
      'bookingFromDate': [bookingFromDate],
      'bookingToDate': [bookingToDate],
      'cartType': [cartType],
      'totalRent': [totalRent],
      'rentCartItemOffers': this.fb.array([
        this.initRentCartItemOffersForm(offerId)
      ])
    });
  }
  initRentCartItemOffersForm(offerId) {
    return this.fb.group({
      'offerId': offerId
    });
  }
  loadAllCartDataByCustomerId() {
    this.spinnerService.show();
    this.cartService.loadAllCartDataByCustomerId(this.customerId).subscribe(s => {
      this.spinnerService.hide();
      this.items = s;
      HeaderComponent.cartData = this.items;
      this.cartItemCountFromDb();
      this.router.navigate(['/check-out/']);
      this.localStorage.removeItem('proceed-checkoutflag');
    },
      (error) => {
        this.spinnerService.hide();
        this.errorStatus = JSON.parse(error._body);
        if (this.errorStatus.status = 404) {
          HeaderComponent.cartCount = 0;
          this.cartError = this.errorStatus.errorMessage
        }
      });
  }
  cartItemCountFromDb() {
    this.spinnerService.show();
    this.cartService.cartItemCount(this.customerId, 'CART').subscribe(s => {
      this.spinnerService.hide();
      HeaderComponent.cartCount = s.count;
    }, (erorr) => {
      this.spinnerService.hide();
    });
  }

  removeErrorMessage() {
    setTimeout(function () {
      this.logincustomerErrorMessage = null;
      this.customerregistrationErrorMessage = null;
      this.customerErrorMessage = null;
      this.customerSuccessMessage = null;
      this.errormessage = null;
      this.userDoesNotExist = null;
      this.passwordSuccessMessage = null;
    }.bind(this), environment.errorTimeoutms);
  }

  checkuserexist(loginData: Login) {
    this.customerErrorMessage = null;
    this.customerErrorMessage = null;
    this.customerSuccessMessage = null;
    this.customerregistrationErrorMessage = null;
    if (loginData.email) {
      this.spinnerService.show();
      this.loginService.isUserExits(loginData.email)
        .subscribe((res) => {
          this.spinnerService.hide();
          if (!res.flag) {
            this.customerregistrationErrorMessage = "Account does not exist"
            this.removeErrorMessage();
          }
        },
          (error) => {
            this.spinnerService.hide();
          });
    }
  }

  checkmobileexist(mobilenumber){
      this.spinnerService.show();
      this.customeService.isMobileExits(mobilenumber)
        .subscribe((res) => {
          this.spinnerService.hide();
          //console.log('res: ' + res);
          if (res) {
            this.customerErrorMessage = "Mobile number already exist."
            this.removeErrorMessage();
          }
        },
        (error) => {
          this.spinnerService.hide();
        });
  }

  getOtpForLogin(loginOtpData) {
    this.loginmobilenumber = loginOtpData.mobilenumber;
    if (loginOtpData.mobilenumber) {
      this.spinnerService.show();
      this.loginService.getloginotp(this.loginmobilenumber)
        .subscribe((res) => {
          this.spinnerService.hide();
          this.loginotpdata = res;
          //console.log(this.loginotpdata);
          //console.log(loginOtpData.loginotp);
          this.loginotp = ""; 
          this.showmobnologin = false;
          this.getotploginbtn = false;
          this.showotptext = true;
          this.submitotploginbtn = true;
        },
          (error) => {
            this.spinnerService.hide();
          });
    } 
  }

  loginviaotp(loginOtpData){
    //alert('here');
    if (loginOtpData.loginotp) {
      this.spinnerService.show();
      this.loginService.loginviaotp(this.loginmobilenumber,loginOtpData.loginotp)
      .subscribe((result) => {
        //console.log(result);
        this.spinnerService.hide();
        if (result) {
          if (this.localStorage.getItem('currentUser')) {
            var currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
            this.role = currentUser.role;
            if (this.role.includes("ROLE_USER")) {
              this.customerSuccessMessage = "You are login successfully!!"
              this.removeErrorMessage()
              this.href = document.referrer;
              this.getparam = this.href.substr(this.href.lastIndexOf('/') + 1);
              //debugger
              if (this.localStorage.getItem('proceed-checkoutflag') == 'true') {
                if (this.localStorage.getItem('currentUser')) {
                  var currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
                  if (currentUser) {
                    this.spinnerService.show();
                    this.customeService.getByUsername(currentUser.username)
                      .subscribe(items => {
                        this.spinnerService.hide();
                        this.customerId = items.userId
                        this.addLocalCartDataToDatabase();
                        this.loadAllCartDataByCustomerId();
                      },
                        (error) => {
                          this.spinnerService.hide();
                        });
                  }
                }
                if (this.cartService.checkLocalStroageIsEmpty() == false) {
                  if (this.localStorage.getItem('cartData')) {
                    this.items = JSON.parse(this.localStorage.getItem('cartData'))
                    for (let i = 0; i < this.items.length; i++) {
                      if (this.items[i].rentCartItemOffers == null) {
                        this.cart_form.push(
                          this.initForm(
                            this.items[i].rentTransactionId,
                            this.items[i].modelId,
                            this.items[i].rentPerDay,
                            (this.items[i].rentPerDay),
                            this.items[i].productQuantity,
                            this.items[i].bookingFromDate,
                            this.items[i].bookingToDate,
                            this.items[i].cartType,
                            ((this.items[i].rentPerDay) * this.items[i].days), 0))
                      }
                      else {
                        if (this.items[i].rentCartItemOffers.length > 0) {
                          this.cart_form.push(
                            this.initForm(
                              this.items[i].rentTransactionId,
                              this.items[i].modelId,
                              this.items[i].rentPerDay,
                              (this.items[i].rentPerDay - (this.items[i].rentPerDay * this.items[i].rentCartItemOffers[0].percentageOffer / 100)),
                              this.items[i].productQuantity,
                              this.items[i].bookingFromDate,
                              this.items[i].bookingToDate,
                              this.items[i].cartType,
                              ((this.items[i].rentPerDay - (this.items[i].rentPerDay * this.items[i].rentCartItemOffers[0].percentageOffer / 100)) * this.items[i].days),
                              this.items[i].rentCartItemOffers[0].offerId))
                        }
                        else {
                          this.cart_form.push(
                            this.initForm(
                              this.items[i].rentTransactionId,
                              this.items[i].modelId,
                              this.items[i].rentPerDay,
                              (this.items[i].rentPerDay),
                              this.items[i].productQuantity,
                              this.items[i].bookingFromDate,
                              this.items[i].bookingToDate,
                              this.items[i].cartType,
                              ((this.items[i].rentPerDay) * this.items[i].days), 0))
                        }
                      }
                    }

                    this.spinnerService.show();
                    this.cartService.addCartDataToDatabase(this.cart_form.value)
                      .subscribe(response => {
                        this.spinnerService.hide();
                        this.localStorage.removeItem('cartData')
                        //this.loadAllCartDataByCustomerId();
                      },
                        (error) => {
                          this.spinnerService.hide();
                        });
                  }
                }
              }
              else if (this.getparam == 'login' || this.getparam == '') {
                this.router.navigate(['/home/']);
              }
              else {
                this._location.back();
              }
            }
          }
        }
      },
        (error) => {
          this.spinnerService.hide();
          this.errorStatus = JSON.parse(error._body);
          if (this.errorStatus.status) {
            this.logincustomerErrorMessage = "Username or Password may be incorrect.";
            this.removeErrorMessage();
            this.invalidLogin = true;
          }
        });
    } 

  }

  getcustomerregister() {
    this.registerForm.reset();
    this.customerregister = true;
    this.forgotpassword = false;
    this.forgotusername = false;
    this.disabledValue = true;
  }
  getforgotpassword(forgotPassword) {
    this.formRequestOtp.reset();
    this.customerregister = false;
    this.forgotpassword = true;
    this.forgotusername = false;
    this.disabledValue = true;
    this.formPasswordRequestOtp.controls['requestFor'].setValue(forgotPassword);
    if (this.formPasswordRequestOtp.controls['requestFor'].value == "forgotPassword") {
      this.displayFormRequestOtp = "block";
      this.displayFormVerifyOtp = "none";
      this.displayFormCreatePassword = "none";
    }
  }
  getforgotusername(forgotUsername) {
    this.formRequestOtp.reset();
    this.customerregister = false;
    this.forgotpassword = false;
    this.forgotusername = true;
    this.disabledValue = true;
    this.formRequestOtp.controls['requestFor'].setValue(forgotUsername);
    if (this.formRequestOtp.controls['requestFor'].value == "forgotMail") {
      this.displayFormRequestOtp = "block";
      this.displayFormVerifyOtp = "none";
      this.displayFormCreatePassword = "none";
    }
  }

  cancelButton() {
    this.removeErrorMessage();
    this.registerForm.reset();
    this.formRequestOtp.reset();
    this.formPasswordRequestOtp.reset();
    this.customerregister = false;
    this.forgotpassword = false;
    this.forgotusername = false;
    this.disabledValue = false;
  }

  /** register customer */
  get legalRegistrationNumbers() {
    return (<FormArray>this.registerForm.controls['legalRegistrationNumbers']).controls
  }
  get userPersonalDetails() {
    return (<FormArray>this.registerForm.controls['userPersonalDetails']).controls
  }
  get communicationDetails() {
    return (<FormArray>this.registerForm.controls['communicationDetails']).controls
  }
  submitPost() {
    let mobilenumber = (<FormArray>(<FormGroup>this.registerForm).controls['communicationDetails']).at(0).get('mobileNoForSMS').value;
    //console.log(mobilenumber);
    this.spinnerService.show();
    this.customeService.isMobileExits(mobilenumber)
      .subscribe((res) => {
        this.spinnerService.hide();
        //console.log('res: ' + res);
        if (res) {
          this.customerErrorMessage = "Mobile number already exist."
          this.removeErrorMessage();
        }
      },
      (error) => {
        this.spinnerService.hide();
      });
    (<FormArray>(<FormGroup>this.registerForm).controls['communicationDetails']).at(0).get('emailForCommunication').setValue(this.registerForm.value.username);
    const formData: any = new FormData();
    formData.append('userLogins', new Blob([JSON.stringify(this.registerForm.value)],
      {
        type: "application/json"
      }));

   // console.log(JSON.stringify(this.registerForm.value));

    if (this.registerForm.controls['username'].valid &&
      this.registerForm.controls['password'].valid) {
      this.spinnerService.show();
      this.customeService.registerCust(formData)
        .subscribe(response => {
          this.spinnerService.hide();
          this.customerSuccessMessage = "Thank you for registering on Voyagekart."
          this.registerForm.reset();
          setTimeout(function () {
            this.customerregister = false;
            this.disabledValue = false;
          }.bind(this), environment.errorTimeoutms);
        },
          (error) => {
            this.spinnerService.hide();
            this.errorStatus = JSON.parse(error._body);
            if (this.errorStatus) {
              this.customerErrorMessage = this.errorStatus.errorMessage
              this.removeErrorMessage()
            }
          });
    }
    else {
      this.customerErrorMessage = "Please fill in all required fields"
      this.removeErrorMessage()
    }
  }


  /** forgot username / password*/
  
  formRequestOtp = new FormGroup({
    email : new FormControl(''),
    otpOption : new FormControl,
    requestFor : new FormControl,
    mobileNo : new FormControl('',Validators.required)
  });

  formPasswordRequestOtp = new FormGroup({
    email : new FormControl('',[Validators.email]),
    otpOption : new FormControl,
    requestFor : new FormControl,
    mobileNo : new FormControl('')
  });
  
  formVerifyOtp = new FormGroup({
    otp: new FormControl('',
      [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(4),
        Validators.pattern("[0-9]+")
      ]
    ),
    userId: new FormControl
  });

  formCreatePassword = this.fb.group({
    userId: [''],
    newPassword: ['', Validators.required],
    confirmPassword: ['', Validators.required]
  },
    {
      validator: PasswordValidators.passwordsShouldMatch
    });


  isLoggedIn() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (currentUser) {
      let token = currentUser && currentUser.token;
      if (token) {
        let jwtHelper = new JwtHelperService();
        let expirationDate = jwtHelper.getTokenExpirationDate(token);
        let isExpired = jwtHelper.isTokenExpired(token);
        if (isExpired) {
          return false;
        }
        else {
          return true;
        }
      }
    }
    else if (currentUser == null) {
      return false;
    }
  }


  /** forgot password */
  emailCheckboxClicked(control: HTMLInputElement) {
    this.emailOptionChecked = control.checked;
    if (!this.smsOptionChecked)
      this.formerror = !control.checked;
  }
  smsCheckboxClicked(control: HTMLInputElement) {
    this.smsOptionChecked = control.checked;
    if (!this.emailOptionChecked)
      this.formerror = !control.checked;
  }
  onSubmitPasswordFormRequestOtp() {
    if (this.formPasswordRequestOtp.invalid) {
      return;
    }
    if (this.smsOptionChecked && this.emailOptionChecked) {
      this.formPasswordRequestOtp.controls['otpOption'].setValue('both');
    } else
      if (this.smsOptionChecked && !this.emailOptionChecked) {
        this.formPasswordRequestOtp.controls['otpOption'].setValue('message');
      }
      else
        if (!this.smsOptionChecked && this.emailOptionChecked) {
          this.formPasswordRequestOtp.controls['otpOption'].setValue('mail');
        }
    //console.log(JSON.stringify(this.formPasswordRequestOtp.value));
    this.spinnerService.show();
    this.service.getOTP(this.formPasswordRequestOtp.value)
      .subscribe(response => {
        this.spinnerService.hide();
        this.responseForRequestOtp = response.json();
        this.displayFormRequestOtp = "none";
        this.displayFormVerifyOtp = "block";
        this.displayFormCreatePassword = "none";
        setTimeout(() => {
          this.displayButtonResendOtp = true;
          this.displayButtonFormVerifyOtpSubmit = false;
          this.otp.markAsPristine({ onlySelf: true });
          this.otp.disable({ onlySelf: true });
          this.incorrectOtp = false;
        }, 1000 * 60);
      }, (error: Response) => {
        this.spinnerService.hide();
        if (error.status === 429) // otp already sent
        {
          this.errormessage = "You are already request for otp";
          this.removeErrorMessage();
        }
        else if (error.status === 406) {
          this.errormessage = "You have reached maximum limit of OTP for the day";
          this.removeErrorMessage(); 
        }
        else if (error.status === 404) {
          this.userDoesNotExist = "User Does not exists.";
          this.removeErrorMessage(); 
        }
      });
  }
  onSubmitPasswordFormVerifyOtp() {
    if (this.formVerifyOtp.invalid) {
      return;
    }
    this.incorrectOtp = false;
    if (this.responseForRequestOtp !== undefined)
      this.formVerifyOtp.controls['userId'].setValue(this.responseForRequestOtp.userId);
    this.spinnerService.show();
    this.service.verifyOTP(this.formVerifyOtp.value)
      .subscribe(
        response => {
          this.spinnerService.hide();
          this.responseForVerifyOtp = response.json();
          this.displayFormRequestOtp = "none";
          this.displayFormVerifyOtp = "none";
          this.displayFormCreatePassword = "block";
        }, error => {
          this.spinnerService.hide();
          this.incorrectOtp = true;
        });
  }
  onButtonResendOtpForPassword() {
    this.otp.enable({ onlySelf: true });
    this.incorrectOtp = false;
    this.displayButtonResendOtp = false;
    this.displayButtonFormVerifyOtpSubmit = true;
    this.formVerifyOtp.get('otp').setValue("");
    this.formVerifyOtp.get('otp').markAsUntouched({ onlySelf: true });
    setTimeout(() => {
      this.displayButtonResendOtp = true;
      this.displayButtonFormVerifyOtpSubmit = false;
      this.otp.markAsPristine({ onlySelf: true });
      this.otp.disable({ onlySelf: true });
      this.incorrectOtp = false;
    }, 1000 * 60);
    this.spinnerService.show();
    this.service.getOTP(this.formPasswordRequestOtp.value).subscribe(response => {
      this.spinnerService.hide();
      this.responseForRequestOtp = response.json();
      this.displayFormRequestOtp = "none";
      this.displayFormVerifyOtp = "block";
      this.displayFormCreatePassword = "none";
    }, (error) => {
      this.spinnerService.hide();
    });
  }
  onSubmitFormCreatePassword() {
    this.formCreatePassword.controls['userId'].setValue(this.responseForRequestOtp.userId);
    if (this.formCreatePassword.invalid) {
      return;
    }
    //console.log(this.formCreatePassword.value);
    this.spinnerService.show();
    this.service.createPassword(this.formCreatePassword.value)
      .subscribe(response => {
        this.spinnerService.hide();
        this.responseForCreateNewPasswordOtp = response.json();
        //console.log("response "+JSON.stringify(this.responseForCreateNewPasswordOtp)) 
        this.passwordSuccessMessage = "Password reset successfully";
        this.removeErrorMessage();
        this.displayFormRequestOtp = "none";
        this.displayFormVerifyOtp = "none";
        this.displayFormCreatePassword = "none";
        this.cancelButton();
        this.disabledValue = false; 
      }, (error) => {
        this.spinnerService.hide();
      });
  }
  get forgotpasswordemail() {
    return this.formPasswordRequestOtp.get('email');
  }
  get password() {
    return this.formCreatePassword.get('password');
  }
  get confirmPassword() {
    return this.formCreatePassword.get('confirmPassword');
  }

  /** forgot username */
  onSubmitFormRequestOtp() {
    if (this.formRequestOtp.invalid) {
      return;
    }
    this.formRequestOtp.controls['otpOption'].setValue('message');
    //console.log("get username JSON" + JSON.stringify(this.formRequestOtp.value));
    this.spinnerService.show();
    this.forgotUserservice.getOTP(this.formRequestOtp.value)
      .subscribe(
        response => {
          this.spinnerService.hide();
          this.responseForRequestOtp = response.json();
          this.displayFormRequestOtp = "none";
          this.displayFormVerifyOtp = "block";
          this.displayFormCreatePassword = "none";
          setTimeout(() => {
            this.displayButtonResendOtp = true;
            this.displayButtonFormVerifyOtpSubmit = false;
            this.otp.markAsPristine({ onlySelf: true });
            this.otp.disable({ onlySelf: true });
            this.incorrectOtp = false;
          }, 1000 * 60);
        },
        (error: Response) => {
          this.spinnerService.hide();
          if (error.status === 429) // otp already sent
          {
            this.errormessage = "You are already request for otp";
            this.removeErrorMessage();
          }
          else if (error.status === 406) {
            this.errormessage = "You have reached maximum limit of OTP for the day";
          }
          else if (error.status === 404) {
            this.userDoesNotExist = true;
          }
        });
  }
  onSubmitFormVerifyOtp() {
    if (this.formVerifyOtp.invalid) {
      return;
    }
    this.incorrectOtp = false;
    if (this.responseForRequestOtp !== undefined)
      this.formVerifyOtp.controls['userId'].setValue(this.responseForRequestOtp.userId);
    this.spinnerService.show();
    this.forgotUserservice.verifyOTP(this.formVerifyOtp.value)
      .subscribe(
        response => {
          this.spinnerService.hide();
          this.responseForVerifyOtp = response.json();
          this.displayFormRequestOtp = "none";
          this.displayFormVerifyOtp = "none";
          this.router.navigate(['/login', this.responseForRequestOtp.userName]);
        },
        error => {
          this.spinnerService.hide();
          this.incorrectOtp = true;
        });
  }
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(
      field => {
        const control = formGroup.get(field);
        if (control instanceof FormControl) {
          control.markAsTouched({ onlySelf: true });
        }
        else
          if (control instanceof FormGroup) {
            this.validateAllFormFields(control);
          }
      });
  }
  onButtonResendOtp() {
    this.otp.enable({ onlySelf: true });
    this.incorrectOtp = false;
    this.displayButtonResendOtp = false;
    this.displayButtonFormVerifyOtpSubmit = true;
    this.formVerifyOtp.get('otp').setValue("");
    this.formVerifyOtp.get('otp').markAsUntouched({ onlySelf: true });
    setTimeout(() => {
      this.displayButtonResendOtp = true;
      this.displayButtonFormVerifyOtpSubmit = false;
      this.otp.markAsPristine({ onlySelf: true });
      this.otp.disable({ onlySelf: true });
      this.incorrectOtp = false;
    }, 1000 * 60);
    this.spinnerService.show();
    this.service.getOTP(this.formRequestOtp.value).subscribe(response => {
      this.spinnerService.hide();
      this.responseForRequestOtp = response.json();
      this.displayFormRequestOtp = "none";
      this.displayFormVerifyOtp = "block";
      this.displayFormCreatePassword = "none";
    }, (error) => {
      this.spinnerService.hide();
    });
  }
  get forgotuseremail() {
    return this.formRequestOtp.get('email');
  }
  get mobileNo() {
    return this.formRequestOtp.get('mobileNo');
  }
  get otp() {
    return this.formVerifyOtp.get('otp');
  }
}