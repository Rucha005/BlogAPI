import { LOCAL_STORAGE } from '@ng-toolkit/universal';
import {Injectable, Inject} from '@angular/core';
import {Http, Response, Headers, URLSearchParams, RequestOptions} from '@angular/http';
import { HttpClientModule } from '@angular/common/http'; 
import { HttpModule } from '@angular/http';
import {Observable, BehaviorSubject} from 'rxjs';
import {IUserLoginData} from './IUserLoginData';
import {JwtHelperService} from '@auth0/angular-jwt';
import 'rxjs/add/operator/map';
import {Router, ActivatedRoute} from '@angular/router';
import { AllServices } from '../../common/allservices.services';

@Injectable()
export class LoginService implements IUserLoginData {
  
  constructor(@Inject(LOCAL_STORAGE) private localStorage: any, private http: Http, private router: Router, private route: ActivatedRoute) 
  {
    this.loginUrl = AllServices.ip + "/auth";
  }

  loginUrl: string;
  token: any;
  jwtHelper: JwtHelperService;
  public currentUser: any;
  username: string;
  sub: string;
  aud: string;
  exp: string;
  iat: string;
  role: string;
  private headers = new Headers({
  'content-type': 'application/json'
  });

  loginData: IUserLoginData;
  login(email: string, password: string){
    let returnUrl = this.route.snapshot.queryParamMap.get('returnUrl') || '/';
    this.localStorage.setItem('returnUrl', returnUrl);
    return this.http.post(this.loginUrl, JSON.stringify({username: email, password: password}), {headers: this.headers})
    .map((response: Response) => {
          let result = response.json();
          if (result) {
              this.token = response.json() && response.json().token;
              this.jwtHelper = new JwtHelperService();
              this.loginData = this.jwtHelper.decodeToken(this.token);
              //console.log("token data " + JSON.stringify(this.loginData));
              //console.log("token:  " + this.token);
              this.localStorage.setItem('currentUser', JSON.stringify({
                token: this.token,
                username: this.loginData.username,
                role: this.loginData.role
              }));
              let tokendata = this.localStorage.getItem('currentUser');
              //console.log("token data is : " + tokendata);
              this.localStorage.setItem('currentUser', tokendata);

              return true;
          }else {

            return false;
          }
    })
    }
    
    isLoggedIn() 
    {
      
      if( this.localStorage.getItem('currentUser') )
      {
        this.currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
        if (this.currentUser) 
        {
          let token = this.currentUser.token;
          if (token) 
          {
            let jwtHelper = new JwtHelperService();
            let expirationDate = jwtHelper.getTokenExpirationDate(token);
            let isExpired = jwtHelper.isTokenExpired(token);
            if (isExpired) 
            {
              // this.localStorage.removeItem('currentUser');
              // this.localStorage.removeItem('cartData');
              // this.router.navigate(['/home/']);
              // return false;
              return true;
            }
            else{
              return true;
            }
          }
        }
      }
      else{
        return false;
      }
   
    
  }
  
  getToken(): String 
  {
    var token = null;
    if( this.localStorage.getItem('currentUser') )
    {
      var currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
      token = currentUser && currentUser.token;
    }

    return (token!=null) ? token : "";
  }
  //Check Customer Already Exits or Not 
  isUserExits(username){
    return this.http.get( AllServices.isUserExits+"?username="+username)
    .map(res => res.json());
  }

  //login via otp
  getloginotp(mobilenumebr){
    return this.http.get( AllServices.getloginotp+"?mono="+mobilenumebr)
    .map(res => res.json());
  }
  loginviaotp(mobilenumebr,otp){
    return this.http.get( AllServices.loginviaotp+"?mono="+mobilenumebr+"&otp="+otp)
    .map((response: Response) => {
      let result = response.json();
      if (result) {
          this.token = response.json() && response.json().token;
          this.jwtHelper = new JwtHelperService();
          this.loginData = this.jwtHelper.decodeToken(this.token);
          //console.log("token data " + JSON.stringify(this.loginData));
          //console.log("token:  " + this.token);
          this.localStorage.setItem('currentUser', JSON.stringify({
            token: this.token,
            username: this.loginData.username,
            role: this.loginData.role
          }));
          let tokendata = this.localStorage.getItem('currentUser');
          //console.log("token data is : " + tokendata);
          this.localStorage.setItem('currentUser', tokendata);

          return true;
      }else {

        return false;
      }
    });  
  }
}