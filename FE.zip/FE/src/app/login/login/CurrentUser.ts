export class CurrentUser {
   constructor( 
      public AccountStatus:string,
      public role: string,
      public src:string,
      public accountName:string ,
      public userId:number
    ) { 
   }
} 