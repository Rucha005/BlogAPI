import { AllServices } from './../common/allservices.services';
import { LoginService } from './login/login.service';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginRoutingModule } from './login-routing.module';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ForgotPasswordModule } from '../forgot-password/forgot-password.module';
import { ForgotUsernameModule } from '../forgot-username/forgot-username.module';
import { CustomerModule } from '../customer/customer.module';
import { RegistartionService } from '../common/registartion.service';



@NgModule({
  imports: [
    CommonModule,
    LoginRoutingModule, 
    FormsModule,
    ReactiveFormsModule,
    ForgotPasswordModule,
    ForgotUsernameModule,
    CustomerModule
  ],
  declarations: [LoginComponent],
  providers:[LoginService,AllServices,RegistartionService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class LoginModule { }
