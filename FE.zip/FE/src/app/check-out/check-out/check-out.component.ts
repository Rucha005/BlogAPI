import {CurrentUser} from '../../login/login/CurrentUser';
import {LoginService} from '../../login/login/login.service';
import {Component, OnInit, Output, EventEmitter} from '@angular/core';
import {PaymentSuccessOrFailureResponse} from './PaymentSuccessOrFailureResponse';
import {Options} from './options';
import {FormArray, FormBuilder, FormGroup, Validators, Form, FormControl} from '@angular/forms';
import {RequestOptions} from '@angular/http';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { ErrorStatus } from '../../common/ErrorStatus';
import { Products } from '../../products/products/products';
import { ProductCartService } from '../../common/product-cart.service';
import { RegistartionService } from '../../common/registartion.service';
import { ProductService } from '../../common/product.service';
import { AddressService } from '../../common/address.service';
import { HeaderComponent } from '../../header/header/header.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

declare var myExtObject: any;
declare var webGlObject: any;

@Component({
  selector: 'app-check-out',
  templateUrl: './check-out.component.html',
  styleUrls: ['./check-out.component.css'],
  host : {'(window:on-payumoney-repsonse)':'placeOrder($event)' }
})
export class CheckOutComponent implements OnInit {
  ValOption: any;
  errorModal: boolean;
  confirmationmodal: boolean;
  couponoptionselectionmessage: string;
  checkcouponoptionselected: boolean =false;
  validcouponenabled: boolean;
  validationerrormessage1: string;
  validationerrormessage: string;
  collapseorderId: string;
  collapsepaymentId: string;
  defaultopentab: boolean = true;
  ordervalidation: boolean = false;
  addressdatavalidation: boolean = false;
  deleteCartData: any;
  deleteProductModal: boolean;
  cartCount: number;
  index: any;
  servicecalled: boolean;
  customerId: any;
  items: Products[] = [];
  errorStatus: ErrorStatus;
  address: any;
  addressdata:string;
  cartErrorMessage = null;
  addressErrorMessage:string;
  addressFormData:any;
  orderPlaceFlag = false;
  orderDataFlag = false;
  localCartData: Products[] = [];
  accountName: string;
  rentOrderId: number;
  firstname: string;
  userEmail: string;
  userPhone: string;
  key:string;
  txnid:string;
  hash:string;
  private _confirmOrderform: FormGroup;
  private payumoneyForm :FormGroup;
  LegalDocumentForm: FormGroup;
  specialPrice: number;
  rentPerDay: number;
  percentage: number;
  selectedPaymentOptionValue= null; 
  static paymentSuccessOrFailure:any;
  ShowAddressSelected = true;
  data : string;
  payementOrderData;
  addressForm: FormGroup;
  couponForm: FormGroup;
  customerErrorMessage= null;
  customerSuccessMessage= null;
  couponErrorMessage=null;
  couponSuccessMessage=null;
  showSelected: boolean;
  addtesstype:any;
  ShowDeliverAddressSelected =false;
  couponofferId:number;
  coupondata:any;
  couponshowoption:boolean;
  couponselectedvalue:any;
  doctype:any;
  documentverificationstatus:any;
  customerDocument:Array<File> = [];
  legaldata:any;

  @Output() eventNavigateToMyOrder = new EventEmitter<boolean>();
  
  constructor(private cartService: ProductCartService, 
    private _fb: FormBuilder, private loginService: LoginService,private registrationservice: RegistartionService,private spinnerService: Ng4LoadingSpinnerService,
    private productService: ProductService, private route: ActivatedRoute, private router: Router,private addressservice: AddressService) 
  {
    this.addressForm = this._fb.group(
    {
      'addressId':[null, Validators.required],
	    'addressType':['', Validators.required],
	    'city':['', Validators.required],
	    'houseNo':['', Validators.required],
	    'landmark':['', Validators.required],
	    'localityArea':['', Validators.required],
	    'nameOfHouse':['', Validators.required],
	    'pinNo':['', Validators.required],
	    'road':['', Validators.required],
	    'state':['Maharashtra', Validators.required],
	    'alternatePhone':[''],
	    'coNote':['']
    }) 
    this.couponForm = this._fb.group(
    {
      'couponcode':['',Validators.required]
    })  
    this.LegalDocumentForm = this._fb.group(
    {
      'legalRegiNumberId': [null, Validators.required],
      'docNumber': ['',Validators.required],
      'docScan': ['', Validators.required],
      'docType': ['', Validators.required],
      'verificationStatus': ['', Validators.required],
      'remark': ['', Validators.required]
    });
  } 
  /**add new address form display on button click */
  ShowButton() 
  {
    this.addressForm.reset();
    this.showSelected = true;
  }
  /** hide new address form on button click */
  HideButton() 
  {
    this.showSelected = false;
  }
  /** check login and confirm order form */
  ngOnInit() 
  {
    if (this.loginService.isLoggedIn()) 
    {
          localStorage.removeItem('cartData');
          this.getByUsername();
    }
    else 
    {
      this.router.navigate(['view-cart']);
    }
    this._confirmOrderform = this._fb.group(
    {
      "customerId": ['',],
      "deliveryAddressInDetail":['', [Validators.required]],
      "paymentMode":['COD', [Validators.required]],
      "modeDetails": ['', [Validators.required]],
      "amount": [ , [Validators.required]],
      "sgst": [0, ],
      "cgst": [0, ],
      "igst": [0,],
      "charges1": [0, ],
      "charges2": [0, ],
      "deliveryCharges": ['', [Validators.required]],
      "trackerId": [0,],
      "response": ['', ],
      "status": ['',],
      "onOrderTotalCouponCode":[,],
      "rentOrderItems": this._fb.array([])
    });
  } 
  /** redirect to payumoney*/
  redirectToPayUMoney()
  {
     const options =
     ({
        "key":  this.key,
        "txnid": this.txnid,
        "hash":this.hash,
        "amount":  this.payementOrderData.amount,
        "firstname": this.firstname,
        "email": this.userEmail,
        "phone":  this.userPhone,
        "productinfo": "product_info",
        "surl": "http://192.168.0.231:9091/html",
        "furl": "http://192.168.0.231:9091/payumoney/failure"
      }); 
      var Handler = 
      {
        responseHandler: function(BOLT)
        {
           CheckOutComponent.paymentSuccessOrFailure = BOLT;
           window.dispatchEvent(new CustomEvent('on-payumoney-repsonse'));
        },
        catchException: function(BOLT)
        {
        }
      };
       myExtObject.func1(options, Handler)
  }
  /** place order Online payment (payumoney)*/
  placeOrder() 
  {
      if(this.selectedPaymentOptionValue == 'COD')
      {
        return;
      }  
      if(CheckOutComponent.paymentSuccessOrFailure.response.txnStatus == 'CANCEL' && this.selectedPaymentOptionValue == 'onlinePayment' )
      {
        return;
      }
    this.data =  "'" +  JSON.stringify(CheckOutComponent.paymentSuccessOrFailure)+ "'";
    this._confirmOrderform.controls['paymentMode'].setValue(CheckOutComponent.paymentSuccessOrFailure.response.mode);
    this._confirmOrderform.controls['customerId'].setValue(this.customerId);
    this._confirmOrderform.controls['deliveryAddressInDetail'].setValue(this.addressdata);
    this._confirmOrderform.controls['amount'].setValue(this.getGrandTotal);
    this._confirmOrderform.controls['deliveryCharges'].setValue(0);
    this._confirmOrderform.controls['response'].setValue(this.data);
    this._confirmOrderform.controls['status'].setValue(CheckOutComponent.paymentSuccessOrFailure.response.txnStatus);
    // Push Cart Data to orderItems in form
    for (let i = 0; i < this.items.length; i++) 
    {
      if(this.couponofferId && this.items[i].availableFlag && this.items[i].cartType == 'CART')
      {
        (<FormArray>this._confirmOrderform.controls['rentOrderItems']).push(
          this.initOffer(
            this.items[i].rentCartId,
            this.items[i].rentTransactionId,
            this.items[i].modelId,
            this.items[i].rentPerDay,
            (this.getSpecialPrice(this.items[i])),
            this.items[i].productQuantity,
            this.items[i].deliverydate,
            this.items[i].pickupdate,
            this.items[i].bookingFromDate,
            this.items[i].bookingToDate,
            this.couponofferId
        ))
      }
      else
      {
        if(this.items[i].availableFlag && this.items[i].cartType == 'CART')
        { 
          if(this.items[i].rentCartItemOffers.length > 0) 
          {
            (<FormArray>this._confirmOrderform.controls['rentOrderItems']).push(
              this.initOffer(
                  this.items[i].rentCartId,
                  this.items[i].rentTransactionId,
                  this.items[i].modelId,
                  this.items[i].rentPerDay,
                  (this.getSpecialPrice(this.items[i])),
                  this.items[i].productQuantity,
                  this.items[i].deliverydate,
                  this.items[i].pickupdate,
                  this.items[i].bookingFromDate,
                  this.items[i].bookingToDate,
                  this.items[i].rentCartItemOffers[0].offerId
            ))
          } 
          else
          {
            (<FormArray>this._confirmOrderform.controls['rentOrderItems']).push(
              this.initOffer(
                  this.items[i].rentCartId,
                  this.items[i].rentTransactionId,
                  this.items[i].modelId,
                  this.items[i].rentPerDay,
                  (this.getSpecialPrice(this.items[i])),
                  this.items[i].productQuantity,
                  this.items[i].deliverydate,
                  this.items[i].pickupdate,
                  this.items[i].bookingFromDate,
                  this.items[i].bookingToDate,
                  0
              ))
          }
        } 
      }  
    }
    this.spinnerService.show();
    this.cartService.placeOrder(this._confirmOrderform.value)
    .subscribe(response => 
      {
        this.spinnerService.hide();
        localStorage.removeItem('cartData')
        CheckOutComponent.paymentSuccessOrFailure = null;
        this.rentOrderId = response.rentOrderId;
        this.removePlaceOrderedDataFromCart(response.rentOrderId)
      },
      (error) => {
        this.spinnerService.hide();
      }
    );
  } 
  /** place order COD */
  placeCashOnDeliveryOrder(valueOption) 
  {
    this.ValOption = valueOption;
    if(CheckOutComponent.paymentSuccessOrFailure)
    {
      if(CheckOutComponent.paymentSuccessOrFailure.response.txnStatus == 'CANCEL' && this.selectedPaymentOptionValue == 'onlinePayment' )
      {
        this.cartErrorMessage = "Your transaction was cancel... Try Again Online Payment";
        this.removeErrorMessage();
        return;
      }
    }
    this._confirmOrderform.controls['customerId'].setValue(this.customerId);
    this._confirmOrderform.controls['deliveryAddressInDetail'].setValue(this.addressdata);
    this._confirmOrderform.controls['amount'].setValue(this.getGrandTotal);
    this._confirmOrderform.controls['deliveryCharges'].setValue(0);
    this._confirmOrderform.controls['response'].setValue(this.ValOption );
    this._confirmOrderform.controls['status'].setValue(this.ValOption ); 
    this._confirmOrderform.controls['onOrderTotalCouponCode'].setValue(this.couponForm.value.couponcode);       
    // Push Cart Data to orderItems in form
    for (let i = 0; i < this.items.length; i++) 
    {
      if(this.couponofferId && this.items[i].availableFlag && this.items[i].cartType == 'CART')
      {
        (<FormArray>this._confirmOrderform.controls['rentOrderItems']).push(
          this.initOffer(
            this.items[i].rentCartId,
            this.items[i].rentTransactionId,
            this.items[i].modelId,
            this.items[i].rentPerDay,
            (this.getSpecialPrice(this.items[i])),
            this.items[i].productQuantity,
            this.items[i].deliverydate,
            this.items[i].pickupdate,
            this.items[i].bookingFromDate,
            this.items[i].bookingToDate,
            this.couponofferId
        ))
      }
      else
      {
        if(this.items[i].availableFlag && this.items[i].cartType == 'CART')
        { 
          if(this.items[i].rentCartItemOffers.length > 0) 
          {
            (<FormArray>this._confirmOrderform.controls['rentOrderItems']).push(
                this.initOffer(
                  this.items[i].rentCartId,
                  this.items[i].rentTransactionId,
                  this.items[i].modelId,
                  this.items[i].rentPerDay,
                  (this.getSpecialPrice(this.items[i])),
                  this.items[i].productQuantity,
                  this.items[i].deliverydate,
                  this.items[i].pickupdate,
                  this.items[i].bookingFromDate,
                  this.items[i].bookingToDate,
                  this.items[i].rentCartItemOffers[0].offerId
              ))
          } 
          else
          {
              (<FormArray>this._confirmOrderform.controls['rentOrderItems']).push(
                this.initOffer(
                  this.items[i].rentCartId,
                  this.items[i].rentTransactionId,
                  this.items[i].modelId,
                  this.items[i].rentPerDay,
                  (this.getSpecialPrice(this.items[i])),
                  this.items[i].productQuantity,
                  this.items[i].deliverydate,
                  this.items[i].pickupdate,
                  this.items[i].bookingFromDate,
                  this.items[i].bookingToDate,
                  0
              ))
          }
        } 
      } 
    }

    this.spinnerService.show();
    this.cartService.placeOrder(this._confirmOrderform.value)
      .subscribe(response => {
        this.spinnerService.hide();
        localStorage.removeItem('cartData')
        CheckOutComponent.paymentSuccessOrFailure = null;
        this.rentOrderId = response.rentOrderId;
        this.removePlaceOrderedDataFromCart(response.rentOrderId)
      },(error) => {
        this.spinnerService.hide();
      });
  }
  /**option buttons - selected payment mode */
  selectedPaymentOption(value) 
  {
     this.selectedPaymentOptionValue = value;
    if (value == "onlinePayment") 
    {
      // For Generating Hash Value
      this.payementOrderData =  new Options;
      //this.payementOrderData.amount = "1.0";
      this.payementOrderData.amount = this.getGrandTotal + ".0";
      this.payementOrderData.firstname = this.firstname;
      this.payementOrderData.email = this.userEmail;
      this.payementOrderData.phone = this.userPhone;
      this.payementOrderData.productinfo = "product_info";
      this.payementOrderData.surl=  "http://192.168.0.231:9091/html",
      this.payementOrderData.furl=  "http://192.168.0.231:9091/payumoney/failure"
      this.spinnerService.show();
      this.cartService.paymentHash(this.payementOrderData)
      .subscribe(response => 
      {
        this.spinnerService.hide();
        this.key =   response.key;
        this.txnid = response.txnid;
        this.hash = response.hash;
      },
      (error) =>{
        this.spinnerService.hide();
      });
    }
  }
  /**option buttons - selected address*/
  selectedAddressOption(value) 
  {
    let add = value;
    this.addressdata = add.houseNo + " " + add.nameOfHouse +" " + add.localityArea +" "+ add.city +" "+ add.state +" "+ add.pinNo;
    this.ShowDeliverAddressSelected= true;
    this.addressdatavalidation = true;
    this.collapseorderId = "collapseTwo";
    this.collapsepaymentId = "collapseThree";
    this.defaultopentab = false;
    this.getStyle();
  }
  getStyle()
  {
    if(this.addressdatavalidation)
    {
           return "#7682b8"; // enabled
    }
    else
    {
      return "#7682b89c"; // disabled
    }
  }
  /** get calculated rent with quantity and days */
  getRent(cart:Products)
  {
    if(cart.rentCartItemOffers.length > 0)
    {
        for(let  c of cart.rentCartItemOffers)
        {
            if(c.groupNo == 0)
            {
              return this.rentPerDay = cart.rentPerDay
            }
            else 
            {
              return this.rentPerDay = cart.rentPerDay  * cart.productQuantity
            }
        }
         //return this.rentPerDay;
    }
    else if(this.couponofferId && cart.rentCartItemOffers.length  == 0)
    {
      return this.rentPerDay = cart.rentPerDay  * cart.productQuantity
    }
  } 
  /** get customer name after login*/
  getByUsername() 
  {
      const currentUser = JSON.parse(localStorage.getItem('currentUser'));
      this.spinnerService.show();
      this.registrationservice.getByUsername(currentUser.username).subscribe(items => {
        this.spinnerService.hide();  
        this.accountName = currentUser.accountName
        this.customerId = items.userId
        this.firstname = items.firstName
        this.userEmail = currentUser.username
        this.userPhone = items.phone
        this.loadAllOrderDataByCustomerId();
        this.loadUserAddress();
        this.checkDocumentVerificationStatus();
      },(error)=>{
        this.spinnerService.hide();
      });
  }
  /** load user address after login if present */
  loadUserAddress() 
  {
    this.spinnerService.show();
    this.addressservice.loadUserAddress(this.customerId).subscribe(s => 
    {
      this.spinnerService.hide();
      this.address = s;
      if(this.address.length == 1)
      {
        for(let add of this.address)
        {
          this.addressdata = add.houseNo + " " + add.nameOfHouse +" " + add.localityArea +" "+ add.city +" "+ add.state +" "+ add.pinNo;
          this.ShowDeliverAddressSelected= true;
          this.addressdatavalidation = true;
          this.collapseorderId = "collapseTwo";
          this.collapsepaymentId = "collapseThree";
          this.defaultopentab = true;
          this.getStyle();
        }
        
      }
    },
    (error)=>
    {
      this.spinnerService.hide();
    });
  }
  checkValiadtion()
  {
    if(!this.addressdatavalidation)
     this.validationerrormessage = "Please Select Address";
     this.removeErrorMessage();
  }
  continuepayment()
  {
    for(let i=0;i<this.items.length;i++)
    {
      if(this.items[i].rentCartItemOffers.length > 0 && this.items[i].cartType == 'CART')
      {
        if(this.couponForm.value.couponcode && this.checkcouponoptionselected && this.addressdatavalidation)
        {
          this.ordervalidation = true;
          this.collapsepaymentId = "collapseThree";
          this.defaultopentab = false;
        }
        else if(this.couponForm.value.couponcode &&  !this.checkcouponoptionselected)
        {
          this.ordervalidation = false;
          this.collapsepaymentId = "";
          this.couponoptionselectionmessage = "Please select offer above";
          this.removeErrorMessage();
        }
      }
      else if(this.items[i].rentCartItemOffers.length < 0 && this.items[i].cartType == 'CART')
      {
        if(this.couponForm.value.couponcode && this.addressdatavalidation)
        {
          this.ordervalidation = true;
          this.collapsepaymentId = "collapseThree";
          this.defaultopentab = false;  
        }  
      }   
    }
    // this.ordervalidation = true;
    // this.collapsepaymentId = "collapseThree";
    // this.addressdatavalidation = false;
    // this.defaultopentab = false;
  }
  /**load all order summery by customer */
  loadAllOrderDataByCustomerId() 
  {
    this.items = null;
    this.spinnerService.show();
    this.cartService.loadAllOrderDataByCustomerId(this.customerId).subscribe(s => 
    {
      this.spinnerService.hide();
      this.items=s;
      this.addDataToLocalStroage();
    },
    (error) => 
    {
        this.spinnerService.hide();
        this.errorStatus = JSON.parse(error._body);
        this.orderDataFlag = true;
        if (this.errorStatus.status = 404) 
        {
          this.router.navigate(['/view-cart']);
        }
        // if(this.errorStatus.status = 500){
        //   this.errorModal = true;
        // }
      });
  }
  initOffer(rentCartId,rentTransactionId, modelId, rentPerDay, priceAfterOffer, productQuantity,deliverdate,pickupdate,bookingFromDate,bookingToDate,offerId) 
  {
    return this._fb.group(
    {
      'rentCartId': [rentCartId],
      'rentTransactionId': [rentTransactionId],
      'modelId': [modelId],
      'rentPerDay': [rentPerDay],
      'rentAfterOffer': [priceAfterOffer],
      'orderedProductQuantity': [productQuantity],
      'deliveredQuantity':[0] ,
      'additionalCharges':[0],
      'deliveryDate':[deliverdate],
			'pickupDate':[pickupdate],
			'bookingFromDate':[bookingFromDate],
      'bookingToDate':[bookingToDate],
      'rentOrderItemOffers': this._fb.array([
        this.initRentOrderItemOffersForm(offerId)
	    ])
    });
  }
  initRentOrderItemOffersForm(offerId) 
  {
    return this._fb.group({
      'offerId' : offerId
    });
  }
  /* delete product from order summery*/  
  removePlaceOrderedDataFromCart(rentOrderId)
  {
     this.spinnerService.show();
     this.cartService.removePlaceOrderedDataFromCart(rentOrderId)
      .subscribe(response => {
        this.spinnerService.hide();
        localStorage.removeItem('cartData')
        this.loadAllCartDataByCustomerId();
        this.orderPlaceFlag = true;
      },
      (error) => {
        this.spinnerService.hide();
      });
  }
  /** load all cart data by customer*/ 
  loadAllCartDataByCustomerId() 
  {
    this.spinnerService.show();
    this.cartService.loadAllCartDataByCustomerId(this.customerId).subscribe(s => 
    {
      this.spinnerService.hide();
      this.items = s;
      HeaderComponent.cartCount = this.items.length;
    },
    (error) => 
    {
      this.spinnerService.hide();
      this.errorStatus = JSON.parse(error._body);
      if (this.errorStatus.status = 404) 
      {
        HeaderComponent.cartCount = 0;
      }
    });
  }  
  /** add order summery data to local storage to handle quantity */
  addDataToLocalStroage() 
  {
    this.localCartData = JSON.parse(localStorage.getItem('cartData'))
    if (this.localCartData == null) 
    {
      localStorage.setItem('cartData', JSON.stringify(this.items));
      this.items = JSON.parse(localStorage.getItem('cartData'));
    }
  }
  /** remove (decrease) quantity of product */
  removeQuantity(z,itemsIndex) 
  {
    if (z.productQuantity == 1) 
    {
      this.removeErrorMessage();
      return
    }
    this.items = JSON.parse(localStorage.getItem('cartData'));
    for (let p = 0; p < this.items.length; p++) 
    {
      if (this.items[p].modelId == z.modelId && this.items[p].rentTransactionId == z.rentTransactionId) 
      {
        this.items[p].productQuantity = z.productQuantity - 1;
      }
    }
    localStorage.setItem('cartData', JSON.stringify(this.items));
  }
  /**add (increase) quantity of product */
  addQuantity(product: Products,itemsIndex) 
  {
    this.items = JSON.parse(localStorage.getItem('cartData'));
    for (let p = 0; p < this.items.length; p++) 
    {
      if (this.items[p].modelId == product.modelId && this.items[p].rentTransactionId == product.rentTransactionId) 
      {
        if (this.items[p].netRentableStock == product.productQuantity) 
        {
          this.index = itemsIndex;
          this.cartErrorMessage = "The requested quantity for " + product.modelName + " is not available."
          this.removeErrorMessage();
          return
        }
        this.items[p].productQuantity = product.productQuantity + 1;
      }
    }
    localStorage.setItem('cartData', JSON.stringify(this.items));
  }  
  /**remove product from order summery */
  removeItemFromOrder(z: Products) 
  {
    for (let p = 0; p < this.items.length; p++) 
    {
      if (this.items[p].rentCartId == z.rentCartId) 
      {
        this.items.splice(p, 1);
      }
    }
  }
  /** get address type from dropdown selection */
  addresstype(value) 
  {
    this.addtesstype = value;
  }
  /** get city name from dropdown selection */
  city(value)
  {
      this.addressForm.controls["city"].setValue (value);  
  }
  /**calculate days todate-fromdate */
  dayscal(cart: Products)
  {  
    var date=new Date(cart.bookingFromDate);
    var date1=new Date(cart.bookingToDate);
    let diffc = date1.getTime() - date.getTime();
    let days = Math.round(Math.abs(diffc/(1000*60*60*24)))+1;
    return days;
  }
  /** calculate grandtotal of order */
  get getGrandTotal() 
  {
    let grandTotal = 0;
    let actualPrice = 0;
    if (this.items.length > 0 || this.items != null) 
    {
      for (let p = 0; p < this.items.length; p++) 
      {
        if(this.items[p].availableFlag && this.items[p].cartType == 'CART')
        {
          grandTotal = grandTotal + ( this.getSpecialPrice(this.items[p])* this.dayscal(this.items[p]))
        }
      }
    }
    return grandTotal;
  }
  /** validation - address & payment mode not selected and selection value of payment mode */
  confirmOrder()
  {
    if(!this.documentverificationstatus && this.legaldata == null)
    {
      this.addressErrorMessage = "Please Enter Legal Document Information.";
      this.removeErrorMessage();
    }
    else if(this.addressdata == null) 
    {
      this.addressErrorMessage = "Please Select Address.";
      this.removeErrorMessage();
    }
    else if(this.selectedPaymentOptionValue == null)
    {
      this.addressErrorMessage = "Please Select Payment Option.";
      this.removeErrorMessage();
    }
    else
    {
      if(this.selectedPaymentOptionValue == 'onlinePayment')
      {
        this.redirectToPayUMoney();
      }
      else if(this.selectedPaymentOptionValue == 'COD')
      {
        this.payementOrderData = null;
        this._confirmOrderform.controls['paymentMode'].setValue('COD');
        this.placeCashOnDeliveryOrder('COD')
      }
      else if(this.selectedPaymentOptionValue == 'UPI')
      {
        this.payementOrderData = null;
        this._confirmOrderform.controls['paymentMode'].setValue('UPI');
        this.placeCashOnDeliveryOrder('UPI')
      } 
      else if(this.selectedPaymentOptionValue == 'Paytm')
      {
        this.payementOrderData = null;
        this._confirmOrderform.controls['paymentMode'].setValue('Paytm');
        this.placeCashOnDeliveryOrder('Paytm')
      } 
      else if(this.selectedPaymentOptionValue == 'NEFT')
      {
        this.payementOrderData = null;
        this._confirmOrderform.controls['paymentMode'].setValue('NEFT');
        this.placeCashOnDeliveryOrder('NEFT')
      }
    }    
  }
  /** remove error message after 5 seconds */
  removeErrorMessage() 
  {
    setTimeout(function() 
    {
      this.cartErrorMessage = null;
      this.addressErrorMessage = null;
      this.customerSuccessMessage = null;
      this.customerErrorMessage = null;
      this.couponErrorMessage =null;
      this.validationerrormessage =null;
      this.validationerrormessage1 =null;
      this.couponoptionselectionmessage =null;
    }.bind(this), 5000);
  }
  /** calculate price after cash offer  */
  getSpecialPrice(z: Products)
  {
    if(this.couponofferId)
    {
      return this.specialPrice= (z.rentPerDay - ((z.rentPerDay * this.coupondata.percentageOffer / 100))) * z.productQuantity    
    }
    else if(this.couponofferId && z.rentCartItemOffers.length == 0)
    {
      return this.specialPrice = z.rentPerDay * z.productQuantity;
    }
    else if (z.rentCartItemOffers.length == 0) 
    {
      return this.specialPrice = z.rentPerDay * z.productQuantity;
    }
    else if(z.rentCartItemOffers.length > 0)
    {
      for (let c of z.rentCartItemOffers) 
      {
        if (c.groupNo == 0) 
        {
          if(this.couponofferId)
          {
            this.specialPrice= (z.rentPerDay - ((z.rentPerDay * this.coupondata.percentageOffer / 100))) * z.productQuantity    
            break;
          }
          else
          {
            this.specialPrice = (z.rentPerDay - ((z.rentPerDay * c.percentageOffer / 100))) * z.productQuantity
            break;  
          } 
        }
        else 
        {
          this.specialPrice = z.rentPerDay * z.productQuantity;
        }
      }
      return this.specialPrice;
    }
    else 
    {
      this.specialPrice = z.rentPerDay * z.productQuantity;
    }
  }
  /** caalculate rent after cash offers */
  getrentPerDay(z: Products)
  {
    if (z.rentCartItemOffers.length > 0) 
    {
      for (let c of z.rentCartItemOffers) 
      {
        if (c.groupNo == 0) 
        {
          this.rentPerDay = z.rentPerDay * z.productQuantity
          break;
        }
        else 
        {
          this.specialPrice = z.rentPerDay * z.productQuantity
        }
      }
      return this.rentPerDay;
    }
  }
  /** get percentage offers */
  getPercentage(z: Products) 
  {
    if (z.rentCartItemOffers.length > 0) 
    {
      for (let c of z.rentCartItemOffers) 
      {
        if (c.groupNo == 0) 
        {
          this.percentage = c.percentageOffer
          break;
        }
        else 
        {
          this.percentage = 0;
        }
      }
      return this.percentage;
    }
  }
  resetaddress()
  { 
    this.addressForm.controls["addressId"].setValue(null);
    this.customerErrorMessage = null;
    this.customerSuccessMessage = null;
    this.addressForm.controls["addressId"].reset();
    this.addressForm.controls["houseNo"].reset(); 
    this.addressForm.controls["landmark"].reset(); 
    this.addressForm.controls["localityArea"].reset(); 
    this.addressForm.controls["nameOfHouse"].reset(); 
    this.addressForm.controls["pinNo"].reset(); 
    this.addressForm.controls["road"].reset();
  }
  /** add address */
  submitAddress()
  {  
    if(this.addtesstype == null) 
    {
      this.addressForm.controls["addressType"].setValue ('Home');
    }
    else
    {
      this.addressForm.controls["addressType"].setValue(this.addtesstype);
    }
    if(this.addressForm.controls["houseNo"].valid && this.addressForm.controls["localityArea"].valid && this.addressForm.controls["nameOfHouse"].valid && this.addressForm.controls["pinNo"].valid && this.addressForm.controls["road"].valid) 
    {
      this.spinnerService.show();
      this.addressservice.addAddress(this.addressForm.value,this.customerId)
        .subscribe(response => 
        { 
          this.spinnerService.hide();
          this.customerSuccessMessage = "Address register!!"
          this.removeErrorMessage();
          this.loadUserAddress();
          this.HideButton();
          this.selectedAddressOption(this.addressForm.value);
          this.addressForm.reset();
        },
        (error)=>
        {
          this.spinnerService.hide();
          this.customerErrorMessage = "Error in registration!!"
          this.removeErrorMessage()
        });
      }
      else
      {
        this.customerErrorMessage = "Please fill in all required fields"
        this.removeErrorMessage();
        return;
      }       
  }
  /** Edit Address */
  editAddress(address)
  {
    //console.log("editAddress: " + JSON.stringify(address))
    this.addressForm.controls["addressId"].setValue (address.addressId);
    this.addressForm.controls["addressType"].setValue (address.addressType);
    this.addressForm.controls["city"].setValue (address.city);
    this.addressForm.controls["houseNo"].setValue (address.houseNo);
    this.addressForm.controls["landmark"].setValue (address.landmark);
    this.addressForm.controls["localityArea"].setValue (address.localityArea);
    this.addressForm.controls["nameOfHouse"].setValue (address.nameOfHouse);
    this.addressForm.controls["pinNo"].setValue (address.pinNo);
    this.addressForm.controls["road"].setValue (address.road);
    this.addressForm.controls["state"].setValue (address.state);
    this.addressForm.controls["alternatePhone"].setValue (address.alternatePhone);
    this.addressForm.controls["coNote"].setValue (address.coNote);
    this.showSelected = true;
  }
  /**Check coupon is valid or not */
  checkCoupon()
  {   
    this.couponSuccessMessage =null;
    this.spinnerService.show();
    this.cartService.getCouponDetails(this.couponForm.value.couponcode).subscribe(s => 
    {
      this.spinnerService.hide();
      this.coupondata = s;
      this.couponSuccessMessage = this.coupondata.percentageOffer + "% offer available on this coupon";
      for(let i=0;i<this.items.length;i++)
      {
        if(this.items[i].rentCartItemOffers.length > 0 && this.items[i].cartType == 'CART' )
        {
              this.couponshowoption = true;
              if(this.couponselectedvalue == 'coupon')
              {
                this.couponofferId = this.coupondata.offerId; 
              }
              else
              {
                this.couponofferId = null;
              }
        }
        else if(this.items[i].cartType == 'CART')
        {
              this.couponofferId = this.coupondata.offerId; 
        }
      }
    },
    (error)=>
    {
      this.spinnerService.hide();
      this.errorStatus = JSON.parse(error._body);
      if (this.errorStatus.status = 404) 
      {
        this.couponErrorMessage =  "Invalid Coupon Code"
        this.removeErrorMessage()
      }
      else if(this.errorStatus)
      {
        this.couponErrorMessage =  this.errorStatus.errorMessage
        this.removeErrorMessage()
      }
    });
  }
  checkVal()
  {
    for(let i=0;i<this.items.length;i++)
    {
      if(this.items[i].rentCartItemOffers.length > 0 && this.items[i].cartType == 'CART')
      {
        if(this.couponForm.value.couponcode && this.checkcouponoptionselected && this.addressdatavalidation)
        {
          this.ordervalidation = true;
          this.collapsepaymentId = "collapseThree";
          this.defaultopentab = false;
          this.getCouponstyle();
        }
        else if(this.couponForm.value.couponcode &&  !this.checkcouponoptionselected)
        {
          this.ordervalidation = false;
          this.collapsepaymentId = "";
          this.couponoptionselectionmessage = "Please select offer above";
          this.removeErrorMessage();
        }
      }
      else if(this.items[i].rentCartItemOffers.length < 0)
      {
        if(this.couponForm.value.couponcode && this.addressdatavalidation)
        {
          this.ordervalidation = true;
          this.collapsepaymentId = "collapseThree";
          this.defaultopentab = false;  
        }  
      }   
    }
  }
  getCouponstyle()
  {
    if(this.couponForm.value.couponcode && this.checkcouponoptionselected || this.addressdatavalidation)
    {
      return "#7682b8"; // enabled
    }
    else
    {
      return "#7682b89c"; // disabled
    }
  }
  /** slection for offer applied coupon or days offers */
  selectedCouponOption(value)
  {
    this.couponselectedvalue = value
    if(this.couponselectedvalue == 'coupon')
    {
      this.couponofferId = this.coupondata.offerId;
      this.checkcouponoptionselected = true;
    }
    else
    {
      this.couponofferId = null;
    }
  }
  get legalRegistrationNumbers()
  {
    return (<FormArray>this.LegalDocumentForm.controls['legalRegistrationNumbers']).controls
  }
  /** check legal document submit or not */
  checkDocumentVerificationStatus() 
  {
    this.spinnerService.show();
    this.cartService.checkDocumentVerification(this.customerId).subscribe(s => 
    {
      this.spinnerService.hide();
      this.documentverificationstatus = s;
    },
    (error)=>
    {
      this.spinnerService.hide();
    });
  }
  /** get value for selected document type (aadhar,pan etc)*/
  documenttype(value) 
  {
    this.doctype = value;
  }
  /** get selected file */
  fileChangeEvent(fileInput)
  {
    this.customerDocument = fileInput.target.files;
  }
  /** submit documents */
  submitLegalDocument()
  {
    this.LegalDocumentForm.controls["docType"].setValue(this.doctype);
    const formData: any = new FormData();
    const customerDocument: File = this.customerDocument[0];
    formData.append("customerDocument", customerDocument, customerDocument.name);
    formData.append('documentDetails',new Blob([JSON.stringify(this.LegalDocumentForm.value)],
    {
      type: "application/json"
    }));
    this.spinnerService.show();
    this.registrationservice.UpdateUserLegalDoc(this.customerId,formData)
      .subscribe(response => 
      {
        this.spinnerService.hide();
        this.legaldata = response
        this.customerSuccessMessage = "Your Legal Documents Are Updated Successfully!"
        this.removeErrorMessage();
      },
      (error)=>
      {
          this.spinnerService.hide();
          this.errorStatus = JSON.parse(error._body);
          if (this.errorStatus) 
          {
            this.customerErrorMessage =  this.errorStatus.errorMessage
            this.removeErrorMessage() 
          }
      });   
  }
  cancelModal()
  {
    this.deleteProductModal= false;
    this.confirmationmodal = false;
  }
  showModal(CartData)
  {
    this.deleteProductModal= true;
    this.deleteCartData = CartData
  }
  confirmToRemoveModal()
  {
    if(this.items.length == 1)
    {
      this.cancelModal();
      this.confirmationmodal = true;
    }
    else
    {
      this.confirmationmodal = false;
      this.removeItemFromOrder(this.deleteCartData);
      this.cancelModal();
    } 
  }
  removeItemsFromCheckout()
  {
     this.removeItemFromOrder(this.deleteCartData);
     this.router.navigate(['/view-cart/'])
  }
  navigateToMyOrder()
  {
    this.eventNavigateToMyOrder.emit(true);
    this.router.navigate(['/myaccount/'])
  }
}