import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrderSummeryComponent } from './order-summery/order-summery.component';
import { DatePipe } from '@angular/common';
import { OrderSummeryService } from './order-summery/order-summery.service';

const routes: Routes = [
  {
    path: '',
    component: OrderSummeryComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  providers:[DatePipe,OrderSummeryService],
  exports: [RouterModule]
})
export class OrderSummeryRoutingModule { }
