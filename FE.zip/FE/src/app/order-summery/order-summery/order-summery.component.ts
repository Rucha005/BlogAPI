import { LOCAL_STORAGE } from '@ng-toolkit/universal';
import { Component, OnInit , Inject} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {IMyDpOptions, IMyDate,IMyOptions, IMyDateModel, IMyDateRange} from 'mydatepicker';
import {DatePipe} from '@angular/common';
import { OrderSummeryService } from './order-summery.service';
import { ErrorStatus } from '../../common/ErrorStatus';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-order-summery',
  templateUrl: './order-summery.component.html',
  styleUrls: ['./order-summery.component.css']
})
export class OrderSummeryComponent implements OnInit {

  showmodal: boolean;
  ordersdata: any;
  ErrorMessage: string;
  toDate: string;
  fromDate: any;
  toDateChanged: boolean;
  fromDateChanged: boolean;
  errorStatus: ErrorStatus;
  searchText :any;
  p: number = 1;

  constructor(@Inject(LOCAL_STORAGE) private localStorage: any, private router:Router,private route:ActivatedRoute,
              private datePipe: DatePipe,private service:OrderSummeryService,private spinnerService: Ng4LoadingSpinnerService) {
      this.displayOrdersSummery();  
  }

  ngOnInit() {
  }
  logout() 
  {
    this.localStorage.removeItem('currentUser');
    this.localStorage.removeItem('cartData');
    this.router.navigate(['/home/'])
  }
  private fromDateChange: IMyOptions;
  private toDateChange: IMyOptions;
  public onFromDateChanged(fromdate)
  {
    this.fromDateChanged = true;
    this.fromDateChange=
    {
      dateFormat: 'yyyy-MM-dd',
    };
    this.fromDate = this.datePipe.transform(fromdate.jsdate, 'yyyy-MM-dd');
  }
  onToDateChanged(todate)
  {
    this.toDateChanged = true;
    this.toDateChange=
    {
      dateFormat: 'yyyy-MM-dd',
    };
    this.toDate = this.datePipe.transform(todate.jsdate, 'yyyy-MM-dd');
  }
  displayOrdersSelectingDates()
  {
    this.ordersdata =null;
    this.spinnerService.show();
    this.service.displayOrdersSelectingDates(this.fromDate ,this.toDate)
      .subscribe(items => {
          this.spinnerService.hide();
          this.ordersdata = items;
      },(error)=>{
          this.spinnerService.hide();
          this.errorStatus = JSON.parse(error._body);
          if (this.errorStatus) {
            this.showmodal = true;
            this.ErrorMessage =  this.errorStatus.errorMessage
          }
      }); 
  }
  displayOrdersSummery()
  {
    this.spinnerService.show();
    this.service.displayAllOrders()
      .subscribe(items => {
          this.spinnerService.hide();
          this.ordersdata = items;
      },(error)=>{
          this.spinnerService.hide();
          this.errorStatus = JSON.parse(error._body);
          if (this.errorStatus) {
            this.showmodal = true;
            this.ErrorMessage =  this.errorStatus.errorMessage
          }
      }); 
  }
  closeModal()
  {
    this.showmodal = false;
    this.displayOrdersSummery();  
  }

}
