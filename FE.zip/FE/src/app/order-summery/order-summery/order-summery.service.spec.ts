import { TestBed, inject } from '@angular/core/testing';

import { OrderSummeryService } from './order-summery.service';

describe('OrderSummeryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OrderSummeryService]
    });
  });

  it('should be created', inject([OrderSummeryService], (service: OrderSummeryService) => {
    expect(service).toBeTruthy();
  }));
});
