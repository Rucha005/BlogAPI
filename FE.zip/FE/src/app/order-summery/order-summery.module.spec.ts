import { OrderSummeryModule } from './order-summery.module';

describe('OrderSummeryModule', () => {
  let orderSummeryModule: OrderSummeryModule;

  beforeEach(() => {
    orderSummeryModule = new OrderSummeryModule();
  });

  it('should create an instance', () => {
    expect(orderSummeryModule).toBeTruthy();
  });
});
