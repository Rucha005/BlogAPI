import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';

@Injectable()
export class BlogAllServices 
{
    constructor(){}

    static blogip = environment.blogip;
    
    /** category services */
    static getAllCategoryData = BlogAllServices.blogip + "/category";
    static addNewCategory     = BlogAllServices.blogip + "/category/create";
    static removeCategory     = BlogAllServices.blogip + "/category/delete";
    static updateCategory     = BlogAllServices.blogip + "/category/update";
    static checkCategoryExist = BlogAllServices.blogip + "/category/checkexist";

    /** blog services */
    static getAllBlogData = BlogAllServices.blogip + "/blog";
    static addNewBlog     = BlogAllServices.blogip + "/blog/create";
    static removeBlog     = BlogAllServices.blogip + "/blog/delete";
    static updateBlog     = BlogAllServices.blogip + "/blog/update";

    /** FE UI */
    static getBlogDataById = BlogAllServices.blogip + "/blog";
    static getCategoryName = BlogAllServices.blogip + "/blog/getcategory";
    static getCategoryData = BlogAllServices.blogip + "/blog/getcategorydata";
    static getFeatureData  = BlogAllServices.blogip + "/blog/featureblog";

} 