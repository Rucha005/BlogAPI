import { LOCAL_STORAGE } from '@ng-toolkit/universal';
import { Component, OnInit, Renderer2 , Inject} from '@angular/core';
declare var $: any;

@Component({
  selector: 'app-terms',
  templateUrl: './terms.component.html',
  styleUrls: ['./terms.component.css']
})
export class TermsComponent implements OnInit {
  feeanddepositshowtab: boolean;
  damageshowtab: boolean;
  deliveryshowtab: boolean;
  feeanddepositshow: boolean;
  damageshow: boolean;
  deliveryshow: boolean;
  show: boolean = false;
  shows:boolean = true;
  class:string="collapse in"
  class1:string = "collapse";
  class2:string = "collapse";
  class3:string = "collapse";
  c:string="";
  c1:string = "collapsed";
  c2:string = "collapsed";
  c3:string = "collapsed";
  terms1:string = "deliveryandshipping";
  terms2:string = "damagepolicy";
  terms3:string = "feeanddeposit";
  constructor(@Inject(LOCAL_STORAGE) private localStorage: any, private renderer : Renderer2) { }
  ngOnInit() {}
  ngAfterViewInit()
  {
    if(this.localStorage.getItem('term') )
    {
      this.shows = false;
    }
    
    if(this.localStorage.getItem('terms') )
    {
      let termstype = this.localStorage.getItem('terms');
      if(this.terms1 == termstype)
      {
        this.class1 = "collapse in";
        this.c1 = "";
        this.deliveryshowtab = true;
        this.renderer.selectRootElement('#deliveryandshipping').focus();
        this.shows = false;
        this.deliveryshow = false;
        this.damageshow = true; 
        this.feeanddepositshow = true;
        this.damageshowtab = false;
        this.feeanddepositshowtab = false;
        this.localStorage.removeItem('terms');
      }
      else 
      if(this.terms2 == termstype) 
      {
        this.class2 = "collapse in";
        this.c2 = " ";
        this.class="collapse";
        this.c="collapsed";
        this.damageshowtab = true;
        this.renderer.selectRootElement('#damagepolicy').focus();
        this.shows = false;
        this.deliveryshow = true;
        this.damageshow = false; 
        this.feeanddepositshow = true;
        this.deliveryshowtab = false;
        this.feeanddepositshowtab = false;
        this.localStorage.removeItem('terms');
      }
      else
      if(this.terms3 == termstype) 
      {
        this.class3 = "collapse in";
        this.c3 = " ";
        this.class="collapse";
        this.c="collapsed";
        this.feeanddepositshowtab = true;
        this.renderer.selectRootElement('#feeanddeposit').focus();
        this.shows = false;
        this.deliveryshow = true;
        this.damageshow = true; 
        this.feeanddepositshow = false;
        this.deliveryshowtab = false;
        this.damageshowtab = false;
        this.localStorage.removeItem('terms');
      }
    }
    else{
      this.class="collapse in";
      this.c=" ";
      this.class1 = "collapse";
      this.c1 = "collapsed ";
      this.class2 = "collapse";
      this.c2 = "collapsed ";
      this.class3 = "collapse";
      this.c3 = "collapsed ";
      this.feeanddepositshow = true;
      this.deliveryshow = true;
      this.damageshow = true;
    }
  }
}
