import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { MywishlistRoutingModule } from './mywishlist-routing.module';
import { MywishlistComponent } from './mywishlist/mywishlist.component';

@NgModule({
  imports: [
    CommonModule,
    MywishlistRoutingModule
  ],
  declarations: [MywishlistComponent],
  providers:[DatePipe],
  exports:[MywishlistComponent]
})
export class MywishlistModule { }
