import { Component, OnInit, ViewChild } from '@angular/core';
import { BlogService } from '../blog.service';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpResponse, HttpEventType } from '@angular/common/http';
import { UploadFileService } from '../upload-file.service';
import { environment } from '../../environments/environment';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';


@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {

  errorStatus: any;
  getBlogDataValues: any;
  displayTableFlag: boolean;
  displayAddBlogFlag: boolean = false;
  blogForm: FormGroup;
  blogSuccessMessage: any;
  blogid: any;
  blogErrorMessage: any;
  displayUpdateBlogFlag: boolean;
  getCategoryDataValues: any;
  categoryid: any;
  @ViewChild("myckeditor") ckeditor: any;
  ckeConfig: any;
  displaydescriptionflag: boolean = false;
  blogindex: number;
  categoryname: any;
  categorydata: any;
  blogImageUploadForm: FormGroup;
  filename: any;
  selectedFiles: FileList;
  currentFileUpload: File;
  progress: { percentage: number } = { percentage: 0 };
  imageurl: any;


  constructor(private blogService: BlogService, private fb: FormBuilder, private router: Router, 
              private uploadService: UploadFileService,private spinnerService: Ng4LoadingSpinnerService) {
    this.blogForm = this.fb.group(
      {
        'blogid': [null, Validators.required],
        'name': ['', Validators.required],
        'posted_on': ['', Validators.required],
        'userid': [3, Validators.required],
        'categoryid': [, Validators.required],
        'image': ['', Validators.required],
        'video': ['', Validators.required],
        'shortinformation': ['', Validators.required],
        'description': ['', Validators.required],
        'create_date': ['', Validators.required],
      }
    );
    this.blogImageUploadForm = this.fb.group(
      {
        'file': ['', Validators.required]
      }
    );
    this.ckeConfig = {
      allowedContent: false,
      extraPlugins: 'divarea',
      forcePasteAsPlainText: false
    };
  }
  ngOnInit() {
    this.imageurl = environment.blogip + '/';
    this.getBlogData();
    this.getCategoryData();
  }
  getBlogData() {
    this.displayTableFlag = true;
    this.spinnerService.show();
    this.blogService.getAllBlogData()
      .subscribe(items => {
        this.spinnerService.hide();
        this.getBlogDataValues = items;
        this.getBlogDataValues.image = this.imageurl + this.getBlogDataValues.image;
    }, (error) => {
        this.spinnerService.hide();
        this.errorStatus = JSON.parse(error._body);
      });
  }
  addNewBlog() {
    this.blogForm.reset();
    this.displayTableFlag = false;
    this.displayAddBlogFlag = true;
    this.displayUpdateBlogFlag = false;
  }
  getCategoryData() {
    this.displayTableFlag = true;
    this.blogService.getAllCategoryData()
      .subscribe(items => {
        this.getCategoryDataValues = items;
        for (let i = 0; i < this.getCategoryDataValues.length; ++i) {
          this.getCategoryName(this.getCategoryDataValues[i].categoryid);
          for (let j = 0; j < this.getCategoryDataValues.length; j++) {
            if (this.getCategoryDataValues[i].categoryid == this.categorydata[i][j].categoryid) {
              this.categoryname = this.categorydata[i][j].name;
              //console.log(this.categoryname);
            }
          }
        }
      }, (error) => {
        this.errorStatus = JSON.parse(error._body);
      });
  }
  onChangeCategory(categoryid) {
    this.categoryid = categoryid;
  }
  selectFile(event) {
    this.filename = event.target.value.slice(12);
    this.selectedFiles = event.target.files;
    this.progress.percentage = 0;
    this.currentFileUpload = this.selectedFiles.item(0);
    this.uploadService.pushFileToStorage(this.currentFileUpload).subscribe(event => {
      if (event.type === HttpEventType.UploadProgress) {
        this.progress.percentage = Math.round(100 * event.loaded / event.total);
      } else if (event instanceof HttpResponse) {
        //console.log('File is completely uploaded!');
      }
    });

    this.selectedFiles = undefined;
  }
  submitBlog() {
    this.blogForm.controls['categoryid'].setValue(this.categoryid);
    this.blogForm.controls['image'].setValue(this.filename);
    //console.log(JSON.stringify(this.blogForm.value));
    this.spinnerService.show();
    this.blogService.addNewBlog(this.blogForm.value)
      .subscribe(items => {
        this.spinnerService.hide();
        //console.log(items);
        this.blogid = items.id;
        this.blogSuccessMessage = items.message;
        this.removeMessage();
        setTimeout(() => {
          this.displayTableFlag = true;
          this.displayAddBlogFlag = false;
          this.getBlogData();
        }, 3000);
      }, (error) => {
        this.spinnerService.hide();
        this.blogErrorMessage = "Error in saved record";
        this.removeMessage();
      });
  }
  cancelButton() {
    this.displayTableFlag = true;
    this.displayAddBlogFlag = false;
    this.displayUpdateBlogFlag = false;
  }
  deleteBlog(blogid) {
    this.blogService.deleteBlog(blogid)
      .subscribe(items => {
        //console.log(items);
        this.getBlogData();
      }, (error) => {

      });
  }
  editBlog(blog) {
    this.blogForm.controls["blogid"].setValue(blog.blogid);
    this.blogForm.controls["name"].setValue(blog.name);
    this.blogForm.controls["image"].setValue(blog.image);
    this.blogForm.controls["posted_on"].setValue(blog.posted_on);
    this.blogForm.controls["categoryid"].setValue(blog.categoryid);
    this.blogForm.controls["shortinformation"].setValue(blog.shortinformation);
    this.blogForm.controls["description"].setValue(blog.description);
    this.displayTableFlag = false;
    this.displayAddBlogFlag = false;
    this.displayUpdateBlogFlag = true;
  }
  updateBlog() {
    this.blogid = this.blogForm.controls['blogid'].value;
    this.blogForm.controls['image'].setValue(this.filename);
    //console.log(JSON.stringify(this.blogForm.value));
    this.spinnerService.show();
    this.blogService.updateBlog(this.blogid, this.blogForm.value)
      .subscribe(items => {
        //console.log(items);
        this.spinnerService.hide();
        this.blogSuccessMessage = "Blog updated successfully";
        this.removeMessage();
        setTimeout(() => {
          this.displayTableFlag = true;
          this.displayAddBlogFlag = false;
          this.displayUpdateBlogFlag = false;
          this.getBlogData();
        }, 3000);
      }, (error) => {
        this.spinnerService.hide();
        this.blogErrorMessage = "Error in updating blogs";
        this.removeMessage();
      });
  }
  navigation() {
    this.router.navigate(['/categories/']);
  }
  removeMessage() {
    setTimeout(() => {
      this.blogSuccessMessage = null;
      this.blogErrorMessage = null;
    }, 3000);
  }
  displayInformation(index) {
    for (let i = 0; i < this.getBlogDataValues.length; i++) {
      if (index == i) {
        this.blogindex = i;
        this.displaydescriptionflag = !this.displaydescriptionflag;
      }
    }
  }
  getCategoryName(categoryid) {
    this.blogService.getCategoryName(categoryid)
      .subscribe(items => {
        this.categorydata = items;
      }, (error) => {
      });
  }
  logout() {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('cartData');
    this.router.navigate(['/home/'])
  }
}