import { Component, OnInit } from '@angular/core';
import { BlogService } from '../blog.service';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';


@Component({
  selector: 'app-blog-fe',
  templateUrl: './blog-fe.component.html',
  styleUrls: ['./blog-fe.component.css'],
})
export class BlogFeComponent implements OnInit {
  getBlogDataValues: any;
  categoryid: any;
  getCategoryDataValues: any;
  imageurl: string;

  constructor(private blogService : BlogService,private router: Router,private route : ActivatedRoute) { 
    route.params.subscribe(val => 
      {
        this.categoryid = val.id;       
      });  
  }

  ngOnInit() {
    this.imageurl = environment.blogip + '/';
     if(this.categoryid == undefined){
       this.getBlogData();     
     }else{
      this.getCategoryWiseData(this.categoryid);
      this.getOtherCategoryData();
    }
    
  }

  getBlogData(){
    this.blogService.getAllBlogData()
    .subscribe(items => {
      this.getBlogDataValues = items;
      //console.log(JSON.stringify(this.getBlogDataValues))
    },(error)=>{
    }); 
  } 

  navigatetodetailspage(blog)
  {
    let id = blog.blogid;
    this.router.navigate(['/blog-detail-posts/',id ]);
  }

  getCategoryWiseData(categoryid){
    this.blogService.getCategoryData(categoryid)
    .subscribe(items => {
      this.getBlogDataValues = items;
      //console.log(JSON.stringify(this.getBlogDataValues))
    },(error)=>{
        
    }); 
  }

  getOtherCategoryData(){
    this.blogService.getAllCategoryData()
    .subscribe(items => {
      this.getCategoryDataValues = items;
      //console.log(JSON.stringify(this.getCategoryDataValues))
    },(error)=>{
    }); 
  }

  navigatetoblog(categoryid){
    this.router.navigate(['/blog-posts/',categoryid]);
    location.reload();
  }
}
