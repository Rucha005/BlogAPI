import { LOCAL_STORAGE } from '@ng-toolkit/universal';
import {Component, OnInit, Input, Inject} from '@angular/core';
import {FormGroup, FormBuilder, Validators, FormArray} from '@angular/forms';
import { Products } from '../../products/products/products';
import { ErrorStatus } from '../../common/ErrorStatus';
import { ProductCartService } from '../../common/product-cart.service';
import { LoginService } from '../../login/login/login.service';
import { RegistartionService } from '../../common/registartion.service';
import { ProductService } from '../../common/product.service';
import { HeaderComponent } from '../../header/header/header.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'product-cart',
  templateUrl: './product-cart.component.html',
  styleUrls: ['./product-cart.component.css']
})
//when login and add products into cart
export class ProductCartComponent implements OnInit {

  @Input() product: Products;
  private _Cartform: FormArray;
  errorStatus: ErrorStatus;
  items: Products[] = [];
  newProduct: Products[] = [];
  localCartData: Products[] = [];
  cartCount: number;
  addToCartProduct: Products;
  customerId: number;
  productAddedInCartFlag = 'none';
  
  constructor(@Inject(LOCAL_STORAGE) private localStorage: any, private cartService: ProductCartService, private _fb: FormBuilder, private loginService: LoginService, 
              private productService: ProductService,private registrationservice: RegistartionService,private spinnerService: Ng4LoadingSpinnerService) 
  {  
    if (loginService.isLoggedIn()) 
    {
      this.getByUsername();
    }
  }
  ngOnInit() {
    this._Cartform = this._fb.array([]);
  }
  /**data add to cart */
  addToCart(product: Products) 
  {
    //debugger
    if (this.loginService.isLoggedIn()) 
    {
      this.addToCartToDatabase(product);
    }
    else 
    {
      this.addToCartToLocalStorage(product);
    }
  }
  /** add localstorage data into database */
  addToCartToDatabase(product: Products) 
  {
    product.cartType ="CART";
    this.addToCartProduct = product;
    product.productInUserCartFlag = true;
    this.product.availableFlag = true;
    if(this.product.rentCartItemOffers.length > 0) 
    {
      this._Cartform.push(
        this.initForm(
          this.product.rentTransactionId,
          this.product.modelId,
          this.product.rentPerDay,
          (this.product.rentPerDay-(this.product.rentPerDay * this.product.rentCartItemOffers[0].percentageOffer / 100)),
          this.product.productQuantity,
          this.product.bookingFromDate,
          this.product.bookingToDate,
          this.product.cartType,
          ((this.product.rentPerDay-(this.product.rentPerDay * this.product.rentCartItemOffers[0].percentageOffer / 100))* this.product.days),
          this.product.rentCartItemOffers[0].offerId
        ))
    }
    else
    {
      this._Cartform.push(
        this.initForm(
          this.product.rentTransactionId,
          this.product.modelId,
          this.product.rentPerDay,
          (this.product.rentPerDay-(this.product.rentPerDay * this.product.percentageOffer / 100)),
          this.product.productQuantity,
          this.product.bookingFromDate,
          this.product.bookingToDate,
          this.product.cartType,
          ((this.product.rentPerDay-(this.product.rentPerDay * this.product.percentageOffer / 100))* this.product.days),
          0
        ))
    }

    this.spinnerService.show();   

    this.cartService.addCartDataToDatabase(this._Cartform.value)
    .subscribe(response => 
    {
      this.spinnerService.hide();   
      this.localStorage.removeItem('cartData')
      this.loadAllCartDataByCustomerId();
    },
    (error) => 
    { 
      this.spinnerService.hide();   
    });
  }

  /** load all cart data by customer */
  loadAllCartDataByCustomerId() 
  {
    this.spinnerService.show();   
    this.cartService.loadAllCartDataByCustomerId(this.customerId)
    .subscribe(s => 
    {
      this.spinnerService.hide();   
      this.items = s;
      HeaderComponent.cartCount = s.length;
      HeaderComponent.cartData = s;
    }, 
    (error) => 
    {
      this.spinnerService.hide();   
      this.errorStatus = JSON.parse(error._body);
      if (this.errorStatus.status == 404) 
      {
        this.cartCount = 0;
      }
    });
  }

  addToCartToLocalStorage(product: Products) 
  {
    product.cartType ="CART";
    this.addToCartProduct = product;  
    product.availableFlag =true;
    if(this.localStorage.getItem('cartData'))
    {
      this.localCartData = JSON.parse(this.localStorage.getItem('cartData'))
      if (this.localCartData == null) 
      {
        product.productInUserCartFlag = true;
        product.bookingFromDate;
        product.bookingToDate;
        product.cartType,
        this.newProduct.push(product);
        this.localStorage.setItem('cartData', JSON.stringify(this.newProduct));
        this.productAddedInCartFlag = 'block';
        this.cartItemCountFromLocalStorage();
      }
      else 
      {
        if (this.cartService.checkLocalStroageIsEmpty()) 
        {
          if( this.cartService.addProductInLocalStorage(product) )
          {
            this.productAddedInCartFlag = 'block';
          }
          this.cartItemCountFromLocalStorage();
        }
        else 
        {
          if (this.cartService.checkProductIsAlreadyInLocalStorage(product)) 
          {
            //alert("product already added into cart !")
          }
          else 
          {
            if(this.cartService.addProductInLocalStorage(product) )
            {
                this.productAddedInCartFlag = 'block';
            }
            this.cartItemCountFromLocalStorage();
          }
        }
      }
    }
    else
    {
      this.localCartData = JSON.parse(this.localStorage.getItem('cartData'))
      if (this.localCartData == null) 
      {
        product.productInUserCartFlag = true;
        product.bookingFromDate;
        product.bookingToDate;
        product.cartType,
        this.newProduct.push(product);
        this.localStorage.setItem('cartData', JSON.stringify(this.newProduct));
        this.productAddedInCartFlag = 'block';
        this.cartItemCountFromLocalStorage();
      }
      else 
      {
        if (this.cartService.checkLocalStroageIsEmpty()) 
        {
          if( this.cartService.addProductInLocalStorage(product) )
          {
            this.productAddedInCartFlag = 'block';
          }
          this.cartItemCountFromLocalStorage();
        }
        else 
        {
          if (this.cartService.checkProductIsAlreadyInLocalStorage(product)) 
          {
            //alert("product already added into cart !")
          }
          else 
          {
            if(this.cartService.addProductInLocalStorage(product) )
            {
                this.productAddedInCartFlag = 'block';
            }
            this.cartItemCountFromLocalStorage();
          }
        }
      }
    }
  }

  cartItemCountFromLocalStorage() 
  {
    HeaderComponent.cartCount = 0;
    HeaderComponent.cartData = null;
    if( this.localStorage.getItem('cartData') )
    {
      this.items = JSON.parse(this.localStorage.getItem('cartData'));
      if (this.items != null) 
      {
        HeaderComponent.cartCount = this.items.length;
        HeaderComponent.cartData = this.items;
      }
    }
    else
    {
      this.items = JSON.parse(this.localStorage.getItem('cartData'));
      if (this.items != null) 
      {
        HeaderComponent.cartCount = this.items.length;
        HeaderComponent.cartData = this.items;
      }
    }
  }

  initForm(rentTransactionId, modelId, rentPerDay, rentAfterOffer, productQuantity,bookingFromDate,bookingToDate,cartType,totalRent,offerId) 
  {
    return this._fb.group({
      'cartId': [null],
      'customerId': [this.customerId],
      'rentTransactionId': [rentTransactionId],
      'modelId': [modelId],
      'rentPerDay': [rentPerDay],
      'rentAfterOffer': [rentAfterOffer],
      'productQuantity': [productQuantity],
      'deliveryPinCode': [411030],
      'bookingFromDate' :[bookingFromDate],
      'bookingToDate':[bookingToDate],
      'cartType':[cartType],
      'totalRent':[totalRent],
      'rentCartItemOffers': this._fb.array([
        this.initRentCartItemOffersForm(offerId)
	    ])
    });
  }
  initRentCartItemOffersForm(offerId) 
  {
    return this._fb.group({
      'offerId' : offerId
    });
  }

  getByUsername() 
  {
    if( this.localStorage.getItem('currentUser') )
    {
      const currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
      if (currentUser) {
    
        this.spinnerService.show();   
        this.registrationservice.getByUsername(currentUser.username)
        .subscribe(c => 
        {
          this.spinnerService.hide();   
          this.customerId = c.userId
        },
        (error)=>
        {
          this.spinnerService.hide();   
        });
      }
    }
  }
  onClickContinue() 
  {
    this.productAddedInCartFlag = 'none';
  }
}
