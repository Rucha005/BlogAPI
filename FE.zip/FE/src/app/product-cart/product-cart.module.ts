import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductCartRoutingModule } from './product-cart-routing.module';
import { ProductCartComponent } from './product-cart/product-cart.component';

@NgModule({
  imports: [
    CommonModule,
    ProductCartRoutingModule
  ],
  declarations: [ProductCartComponent],
  exports:[ProductCartComponent]
})
export class ProductCartModule { }