import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForgotPasswordService } from './forgot-password/forgot-password.service';

const routes: Routes = [
  {
    path: '',
    component: ForgotPasswordComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  providers:[ForgotPasswordService],
  exports: [RouterModule]
})
export class ForgotPasswordRoutingModule { }
