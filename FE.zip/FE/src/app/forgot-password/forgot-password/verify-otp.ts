export class VerifyOTP
{
  userId : string;
  otp : string;
}
