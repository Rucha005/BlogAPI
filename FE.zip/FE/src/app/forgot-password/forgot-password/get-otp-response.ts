export class GetOtpResponse
{
  mobileNumber : string;
  userName : string;
  userId : string;
}
