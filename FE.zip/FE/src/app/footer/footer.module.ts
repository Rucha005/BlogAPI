import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FooterRoutingModule } from './footer-routing.module';
import { FooterComponent } from './footer/footer.component';
import { LoginService } from '../login/login/login.service';

@NgModule({
  imports: [
    CommonModule,
    FooterRoutingModule
  ],
  declarations: [FooterComponent],
  exports:[FooterComponent],
  providers:[ LoginService]
})
export class FooterModule { }
