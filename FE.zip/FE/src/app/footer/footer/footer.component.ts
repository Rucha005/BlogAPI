import { LOCAL_STORAGE } from '@ng-toolkit/universal';
import { Component, OnInit, Renderer2 , Inject} from '@angular/core';
import { RouterModule, ActivatedRoute, Router,NavigationEnd} from '@angular/router';
import { PlatformLocation, LocationStrategy } from '@angular/common'
import { HostListener } from '@angular/core';
import { LoginService } from '../../login/login/login.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})

export class FooterComponent 
{
  show: boolean = true;
  constructor(@Inject(LOCAL_STORAGE) private localStorage: any, private location: LocationStrategy,private renderer : Renderer2,
              private loginService: LoginService,private route: ActivatedRoute,private router: Router) 
  {
    location.onPopState(() => 
    {
      setTimeout(() => 
      {
        localStorage.removeItem('term');  
      },3000);
    });
  }
  
  ngAfterViewInit()
  {
    if(this.localStorage.getItem('term'))
    {
       let termstype = this.localStorage.getItem('term');
    }
  }

  get LoginService()
  {
    return this.loginService;
  } 
  
  navigate(value)
  {
    this.localStorage.setItem('terms',value)
    this.localStorage.setItem('term',value)
    this.router.navigate(['/terms/'])
    //window.location.reload();
  }
  
  navigatetomyaccount(value)
  {
    this.localStorage.setItem('term',value)
    if(this.loginService.isLoggedIn() == false)
    {
      this.router.navigate(['/login/'])
    }
    else if(this.loginService.isLoggedIn() == true)
    {
      this.router.navigate(['/myaccount/'])
    }
  }

  navigatetoterms(value)
  {
    this.localStorage.setItem('term',value);
    this.router.navigate(['/terms/']);
  }

  navigatetofaq(value)
  {
    this.localStorage.setItem('term',value);
    this.router.navigate(['/faq/']);
  }

  navigatetoabout(value)
  {
    this.localStorage.setItem('term',value);
    this.router.navigate(['/About Us/']);
  }

  navigatetocontact(value)
  {
    this.localStorage.setItem('term',value);
    this.router.navigate(['/Contact Us/']);
  }

}
