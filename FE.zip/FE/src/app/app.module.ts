import { NgtUniversalModule } from '@ng-toolkit/universal';
import { NgModule } from "@angular/core";
import { AppComponent } from "./app.component";
import { AppRoutingModule } from "./app-routing.module";
import { Ng4LoadingSpinnerModule } from "ng4-loading-spinner";
import { CommonModule } from "@angular/common";
import { HeaderModule } from './header/header.module';
import { FooterModule } from './footer/footer.module';
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HomeModule } from './home/home.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BlogcategoryComponent } from './blogcategory/blogcategory.component';
import { BlogService } from './blog.service';
import { BlogComponent } from './blog/blog.component';
import { BlogFeComponent } from './blog-fe/blog-fe.component';
import { BlogDetailComponent } from './blog-detail/blog-detail.component';
import { CKEditorModule } from 'ng2-ckeditor';
import { CeiboShare } from 'ng2-social-share';
import { HttpClientModule } from '@angular/common/http';
import { UploadFileService } from './upload-file.service';



@NgModule({
  declarations: [
    AppComponent,
    BlogcategoryComponent,
    BlogComponent,
    BlogFeComponent,
    BlogDetailComponent,  
  ],

  imports:[
    CommonModule,BrowserAnimationsModule,FormsModule,CKEditorModule,HttpClientModule,
    ReactiveFormsModule,NgtUniversalModule,BrowserModule,HomeModule,
    CommonModule, AppRoutingModule, Ng4LoadingSpinnerModule.forRoot(), HeaderModule, FooterModule,
     HttpModule],
  providers:[BlogService,CeiboShare,UploadFileService],
})

export class AppModule { }
