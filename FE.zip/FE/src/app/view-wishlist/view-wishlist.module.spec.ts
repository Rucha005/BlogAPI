import { ViewWishlistModule } from './view-wishlist.module';

describe('ViewWishlistModule', () => {
  let viewWishlistModule: ViewWishlistModule;

  beforeEach(() => {
    viewWishlistModule = new ViewWishlistModule();
  });

  it('should create an instance', () => {
    expect(viewWishlistModule).toBeTruthy();
  });
});
