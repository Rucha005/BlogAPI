import { TestBed, inject } from '@angular/core/testing';

import { ViewWishlistService } from './view-wishlist.service';

describe('ViewWishlistService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewWishlistService]
    });
  });

  it('should be created', inject([ViewWishlistService], (service: ViewWishlistService) => {
    expect(service).toBeTruthy();
  }));
});
