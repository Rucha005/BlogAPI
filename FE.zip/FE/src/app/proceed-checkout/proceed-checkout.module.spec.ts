import { ProceedCheckoutModule } from './proceed-checkout.module';

describe('ProceedCheckoutModule', () => {
  let proceedCheckoutModule: ProceedCheckoutModule;

  beforeEach(() => {
    proceedCheckoutModule = new ProceedCheckoutModule();
  });

  it('should create an instance', () => {
    expect(proceedCheckoutModule).toBeTruthy();
  });
});
