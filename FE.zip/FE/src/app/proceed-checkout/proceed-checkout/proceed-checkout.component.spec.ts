import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProceedCheckoutComponent } from './proceed-checkout.component';

describe('ProceedCheckoutComponent', () => {
  let component: ProceedCheckoutComponent;
  let fixture: ComponentFixture<ProceedCheckoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProceedCheckoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProceedCheckoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
