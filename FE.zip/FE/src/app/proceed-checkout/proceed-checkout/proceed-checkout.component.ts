import { Component, OnInit, Input, Inject } from '@angular/core';
import { Products } from '../../products/products/products';
import { FormArray, FormBuilder } from '@angular/forms';
import { ErrorStatus } from '../../common/ErrorStatus';
import { HeaderComponent } from '../../header/header/header.component';
import { ProductService } from '../../common/product.service';
import { ProductCartService } from '../../common/product-cart.service';
import { RegistartionService } from '../../common/registartion.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { LoginService } from '../../login/login/login.service';
import { LOCAL_STORAGE } from '@ng-toolkit/universal';
import { Router } from '@angular/router';

@Component({
  selector: 'app-proceed-checkout',
  templateUrl: './proceed-checkout.component.html',
  styleUrls: ['./proceed-checkout.component.css']
})
export class ProceedCheckoutComponent implements OnInit {

  @Input() product: Products;
  private _Cartform: FormArray;
  errorStatus: ErrorStatus;
  items: Products[] = [];
  newProduct: Products[] = [];
  localCartData: Products[] = [];
  cartCount: number;
  addToCartProduct: Products;
  customerId: number;
  productAddedInCartFlag = 'none';
  
  constructor(@Inject(LOCAL_STORAGE) private localStorage: any, private cartService: ProductCartService, private _fb: FormBuilder, private loginService: LoginService, 
              private productService: ProductService,private registrationservice: RegistartionService,private spinnerService: Ng4LoadingSpinnerService,private route :Router) 
  {  
    if (loginService.isLoggedIn()) 
    {
      this.getByUsername();
    }
  }
  ngOnInit() {
    this._Cartform = this._fb.array([]);
  }

  get LoginService(){
    return this.loginService;
  }

  /**data add to cart */
  addToCart(product: Products) 
  {
    if (this.loginService.isLoggedIn()) 
    {
      this.addToCartToDatabase(product);
      this.route.navigate(['/check-out']);
    }
    else 
    {
      this.addToCartToLocalStorage(product);
      this.localStorage.setItem('proceed-checkoutflag','true');
      this.route.navigate(['/login']);
      
    }
  }
  /** add localstorage data into database */
  addToCartToDatabase(product: Products) 
  {
    product.cartType ="CART";
    this.addToCartProduct = product;
    product.productInUserCartFlag = true;
    this.product.availableFlag = true;
    if(this.product.rentCartItemOffers.length > 0) 
    {
      this._Cartform.push(
        this.initForm(
          this.product.rentTransactionId,
          this.product.modelId,
          this.product.rentPerDay,
          (this.product.rentPerDay-(this.product.rentPerDay * this.product.rentCartItemOffers[0].percentageOffer / 100)),
          this.product.productQuantity,
          this.product.bookingFromDate,
          this.product.bookingToDate,
          this.product.cartType,
          ((this.product.rentPerDay-(this.product.rentPerDay * this.product.rentCartItemOffers[0].percentageOffer / 100))* this.product.days),
          this.product.rentCartItemOffers[0].offerId
        ))
    }
    else
    {
      this._Cartform.push(
        this.initForm(
          this.product.rentTransactionId,
          this.product.modelId,
          this.product.rentPerDay,
          (this.product.rentPerDay-(this.product.rentPerDay * this.product.percentageOffer / 100)),
          this.product.productQuantity,
          this.product.bookingFromDate,
          this.product.bookingToDate,
          this.product.cartType,
          ((this.product.rentPerDay-(this.product.rentPerDay * this.product.percentageOffer / 100))* this.product.days),
          0
        ))
    }

    this.spinnerService.show();   

    this.cartService.addCartDataToDatabase(this._Cartform.value)
    .subscribe(response => 
    {
      this.spinnerService.hide();   
      this.localStorage.removeItem('cartData')
      this.loadAllCartDataByCustomerId();
    },
    (error) => 
    { 
      this.spinnerService.hide();   
    });
  }

  /** load all cart data by customer */
  loadAllCartDataByCustomerId() 
  {
    this.spinnerService.show();   
    this.cartService.loadAllCartDataByCustomerId(this.customerId)
    .subscribe(s => 
    {
      this.spinnerService.hide();   
      this.items = s;
      HeaderComponent.cartCount = s.length;
      HeaderComponent.cartData = s;
    }, 
    (error) => 
    {
      this.spinnerService.hide();   
      this.errorStatus = JSON.parse(error._body);
      if (this.errorStatus.status == 404) 
      {
        this.cartCount = 0;
      }
    });
  }

  addToCartToLocalStorage(product: Products) 
  {
    //debugger
    product.cartType ="CART";
    this.addToCartProduct = product;  
    product.availableFlag =true;
    if(this.localStorage.getItem('cartData'))
    {
      this.localCartData = JSON.parse(this.localStorage.getItem('cartData'))
      if (this.localCartData == null) 
      {
        product.productInUserCartFlag = true;
        product.bookingFromDate;
        product.bookingToDate;
        product.cartType,
        this.newProduct.push(product);
        this.localStorage.setItem('cartData', JSON.stringify(this.newProduct));
        this.productAddedInCartFlag = 'block';
        this.cartItemCountFromLocalStorage();
      }
      else 
      {
        if (this.cartService.checkLocalStroageIsEmpty()) 
        {
          if( this.cartService.addProductInLocalStorage(product) )
          {
            this.productAddedInCartFlag = 'block';
          }
          this.cartItemCountFromLocalStorage();
        }
        else 
        {
          if (this.cartService.checkProductIsAlreadyInLocalStorage(product)) 
          {
            //alert("product already added into cart !")
          }
          else 
          {
            if(this.cartService.addProductInLocalStorage(product) )
            {
                this.productAddedInCartFlag = 'block';
            }
            this.cartItemCountFromLocalStorage();
          }
        }
      }
    }
    else
    {
      this.localCartData = JSON.parse(this.localStorage.getItem('cartData'))
      if (this.localCartData == null) 
      {
        product.productInUserCartFlag = true;
        product.bookingFromDate;
        product.bookingToDate;
        product.cartType,
        this.newProduct.push(product);
        this.localStorage.setItem('cartData', JSON.stringify(this.newProduct));
        this.productAddedInCartFlag = 'block';
        this.cartItemCountFromLocalStorage();
      }
      else 
      {
        if (this.cartService.checkLocalStroageIsEmpty()) 
        {
          if( this.cartService.addProductInLocalStorage(product) )
          {
            this.productAddedInCartFlag = 'block';
          }
          this.cartItemCountFromLocalStorage();
        }
        else 
        {
          if (this.cartService.checkProductIsAlreadyInLocalStorage(product)) 
          {
            //alert("product already added into cart !")
          }
          else 
          {
            if(this.cartService.addProductInLocalStorage(product) )
            {
                this.productAddedInCartFlag = 'block';
            }
            this.cartItemCountFromLocalStorage();
          }
        }
      }
    }
  }

  cartItemCountFromLocalStorage() 
  {
    HeaderComponent.cartCount = 0;
    HeaderComponent.cartData = null;
    if( this.localStorage.getItem('cartData') )
    {
      this.items = JSON.parse(this.localStorage.getItem('cartData'));
      if (this.items != null) 
      {
        HeaderComponent.cartCount = this.items.length;
        HeaderComponent.cartData = this.items;
      }
    }
    else
    {
      this.items = JSON.parse(this.localStorage.getItem('cartData'));
      if (this.items != null) 
      {
        HeaderComponent.cartCount = this.items.length;
        HeaderComponent.cartData = this.items;
      }
    }
  }

  initForm(rentTransactionId, modelId, rentPerDay, rentAfterOffer, productQuantity,bookingFromDate,bookingToDate,cartType,totalRent,offerId) 
  {
    return this._fb.group({
      'cartId': [null],
      'customerId': [this.customerId],
      'rentTransactionId': [rentTransactionId],
      'modelId': [modelId],
      'rentPerDay': [rentPerDay],
      'rentAfterOffer': [rentAfterOffer],
      'productQuantity': [productQuantity],
      'deliveryPinCode': [411030],
      'bookingFromDate' :[bookingFromDate],
      'bookingToDate':[bookingToDate],
      'cartType':[cartType],
      'totalRent':[totalRent],
      'rentCartItemOffers': this._fb.array([
        this.initRentCartItemOffersForm(offerId)
	    ])
    });
  }
  initRentCartItemOffersForm(offerId) 
  {
    return this._fb.group({
      'offerId' : offerId
    });
  }

  getByUsername() 
  {
    if( this.localStorage.getItem('currentUser') )
    {
      const currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
      if (currentUser) {
    
        this.spinnerService.show();   
        this.registrationservice.getByUsername(currentUser.username)
        .subscribe(c => 
        {
          this.spinnerService.hide();   
          this.customerId = c.userId
        },
        (error)=>
        {
          this.spinnerService.hide();   
        });
      }
    }
  }
  onClickContinue() 
  {
    this.productAddedInCartFlag = 'none';
  }

}
