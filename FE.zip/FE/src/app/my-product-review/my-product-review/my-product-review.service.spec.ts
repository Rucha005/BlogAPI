import { TestBed, inject } from '@angular/core/testing';

import { MyProductReviewService } from './my-product-review.service';

describe('MyProductReviewService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MyProductReviewService]
    });
  });

  it('should be created', inject([MyProductReviewService], (service: MyProductReviewService) => {
    expect(service).toBeTruthy();
  }));
});
