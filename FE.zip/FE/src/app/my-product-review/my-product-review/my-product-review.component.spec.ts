import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyProductReviewComponent } from './my-product-review.component';

describe('MyProductReviewComponent', () => {
  let component: MyProductReviewComponent;
  let fixture: ComponentFixture<MyProductReviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyProductReviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyProductReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
