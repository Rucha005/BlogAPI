import { LOCAL_STORAGE } from '@ng-toolkit/universal';
import { Component, OnInit , Inject} from '@angular/core';
import { ErrorStatus } from '../../common/ErrorStatus';
import { RatingService } from '../../common/rating.service';
import { RegistartionService } from '../../common/registartion.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-my-product-review',
  templateUrl: './my-product-review.component.html',
  styleUrls: ['./my-product-review.component.css']
})
export class MyProductReviewComponent implements OnInit {

  customerId: any;
  userData: any;
  username: any;
  reviewErrorMessage: any;
  errorStatus: ErrorStatus;
  servicecalled: boolean;
  customerid: number;
  reviewdata: any;
  constructor(@Inject(LOCAL_STORAGE) private localStorage: any, private ratingservice: RatingService,private registrationservice:RegistartionService,private spinnerService: Ng4LoadingSpinnerService) 
  {
  }
  ngOnInit() {}
  ngAfterViewInit(){
    this.getByUsername();
  }
  
  getByUsername() 
  {
    if( this.localStorage.getItem('currentUser') )
    {
      const currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
      this.spinnerService.show();
      this.registrationservice.getByUsername(currentUser.username)
      .subscribe(items => 
      {
        this.username= currentUser.username; 
        this.userData = items; 
        this.customerId = items.userId
        this.spinnerService.hide();
        this.getReviewByCustomer(this.customerId);
      },
      (error)=>
      {
        this.spinnerService.hide();
      });
    }
  }

  getReviewByCustomer(customerId)
  {
    this.customerid = customerId
    this.spinnerService.show();
    this.ratingservice.getReviewByCustomer(customerId).subscribe(items => {
      this.spinnerService.hide();
       this.reviewdata = items;
    },(error)=>{ 
      this.spinnerService.hide();
      this.errorStatus = JSON.parse(error._body);
      if (this.errorStatus.status = 404) 
      {
        this.reviewErrorMessage =  this.errorStatus.errorMessage
      }
    });
  }

}
