import { Component, OnInit } from '@angular/core';
import { BlogService } from '../blog.service';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-blogcategory',
  templateUrl: './blogcategory.component.html',
  styleUrls: ['./blogcategory.component.css']
})
export class BlogcategoryComponent implements OnInit {
  errorStatus: any;
  getCategoryDataValues: any;
  displayTableFlag: boolean;
  displayAddCategoryFlag: boolean = false;
  categoryForm: FormGroup;
  categorySuccessMessage: any;
  categoryid: any;
  categoryErrorMessage: any;
  displayUpdateCategoryFlag: boolean;
  isexist: boolean = false;

  constructor(private blogService: BlogService, private fb: FormBuilder, private router: Router, 
              private spinnerService: Ng4LoadingSpinnerService) 
  {
    this.categoryForm = this.fb.group(
      {
        'categoryid': [null, Validators.required],
        'name': ['', Validators.required],
        'description': ['', Validators.required],
      }
    );
  }
  ngOnInit() {
    this.getCategoryData();
  }
  getCategoryData() {
    this.displayTableFlag = true;
    this.blogService.getAllCategoryData()
      .subscribe(items => {
        this.getCategoryDataValues = items;
        //console.log(JSON.stringify(this.getCategoryDataValues))
      }, (error) => {
        this.errorStatus = JSON.parse(error._body);
        this.removeMessage();
      });
  }
  addNewCategory() {
    this.categoryForm.reset();
    this.displayTableFlag = false;
    this.displayAddCategoryFlag = true;
    this.displayUpdateCategoryFlag = false;
  }
  submitCategory() {
    this.spinnerService.show();
    this.blogService.addNewCategory(this.categoryForm.value)
      .subscribe(items => {
        //console.log(items);
        this.spinnerService.hide();
        this.categoryid = items.id;
        this.categorySuccessMessage = items.message;
        this.removeMessage();
        setTimeout(() => {
          this.displayTableFlag = true;
          this.displayAddCategoryFlag = false;
          this.getCategoryData();
        }, 3000);
      }, (error) => {
        this.spinnerService.hide();
        this.categoryErrorMessage = "Invalid data";
        this.removeMessage();
      });
  }
  cancelButton() {
    this.displayTableFlag = true;
    this.displayAddCategoryFlag = false;
    this.displayUpdateCategoryFlag = false;
  }
  deleteCategory(categoryid) {
    this.blogService.deleteCategory(categoryid)
      .subscribe(items => {
        //console.log(items);
        this.getCategoryData();
      }, (error) => {
      });
  }
  editCategory(category) {
    this.categoryForm.controls["categoryid"].setValue(category.categoryid);
    this.categoryForm.controls["name"].setValue(category.name);
    this.categoryForm.controls["description"].setValue(category.description);
    this.displayTableFlag = false;
    this.displayAddCategoryFlag = false;
    this.displayUpdateCategoryFlag = true;
  }
  updateCategory() {
    this.spinnerService.show();
    this.categoryid = this.categoryForm.controls['categoryid'].value;
    this.blogService.updateCategory(this.categoryid, this.categoryForm.value)
      .subscribe(items => {
        //console.log(items);
        this.spinnerService.hide();
        this.categorySuccessMessage = "Category updated successfully";
        this.removeMessage();
        setTimeout(() => {
          this.displayTableFlag = true;
          this.displayAddCategoryFlag = false;
          this.displayUpdateCategoryFlag = false;
          this.getCategoryData();
        }, 3000);
      }, (error) => {
        this.spinnerService.hide();
        this.categoryErrorMessage = "Error in updating record";
        this.removeMessage();
      });
  }
  navigation() {
    this.router.navigate(['/blogs/']);
  }
  removeMessage() {
    setTimeout(() => {
      this.categorySuccessMessage = null;
      this.categoryErrorMessage = null;
    }, 3000);
  }
  logout() {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('cartData');
    this.router.navigate(['/home/'])
  }
  checkcategoryexist(categoryname){
    this.blogService.checkCategoryExist(categoryname)
    .subscribe(items => {
      //console.log(items);
      if(items == true){
        this.categoryErrorMessage = "Category already exist";
        this.removeMessage();
        this.isexist = true;
      }
      else{
        this.isexist = false;
      }
    }, (error) => {
    });
  }
}
