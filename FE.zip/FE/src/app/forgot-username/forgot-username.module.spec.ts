import { ForgotUsernameModule } from './forgot-username.module';

describe('ForgotUsernameModule', () => {
  let forgotUsernameModule: ForgotUsernameModule;

  beforeEach(() => {
    forgotUsernameModule = new ForgotUsernameModule();
  });

  it('should create an instance', () => {
    expect(forgotUsernameModule).toBeTruthy();
  });
});
