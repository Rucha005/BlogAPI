import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayLevelsComponent } from './display-levels/display-levels.component';

const routes: Routes = [
  {
    path: '',
    component: DisplayLevelsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DisplayLevelsRoutingModule { }
