import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DisplayLevelsRoutingModule } from './display-levels-routing.module';
import { DisplayLevelsComponent } from './display-levels/display-levels.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { WishlistModule } from '../wishlist/wishlist.module';
import { MatExpansionModule, MatExpansionPanelHeader,} from '@angular/material';
import { BreadcrumbService } from '../common/breadcrumb.service';
import { ProductService } from '../common/product.service';
import { ProductCartService } from '../product-cart/product-cart/product-cart.service';
import { LoginService } from '../login/login/login.service';
import { LevelDataService } from '../common/levelData.service';
import { RegistartionService } from '../common/registartion.service';
import { AllServices } from '../common/allservices.services';
import { FocusMonitor } from '@angular/cdk/a11y';
import { CommonpipesModule } from '../commonpipes/commonpipes.module';
@NgModule({
  imports: [
    CommonModule,
    DisplayLevelsRoutingModule,
    FormsModule, WishlistModule, MatExpansionModule, ReactiveFormsModule, CommonpipesModule
  ],
  declarations: [DisplayLevelsComponent],
  providers:[BreadcrumbService, ProductService,LoginService,ProductCartService,LevelDataService,RegistartionService,AllServices,FocusMonitor]
})
export class DisplayLevelsModule { }
