import { TestBed, inject } from '@angular/core/testing';

import { DisplayLevelsService } from './display-levels.service';

describe('DisplayLevelsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DisplayLevelsService]
    });
  });

  it('should be created', inject([DisplayLevelsService], (service: DisplayLevelsService) => {
    expect(service).toBeTruthy();
  }));
});
