import { LOCAL_STORAGE } from '@ng-toolkit/universal';
import { AllServices } from './allservices.services';
import { Injectable, Inject } from '@angular/core';
import { Http,  Headers,RequestOptions } from '@angular/http';
import { Products } from '../products/products/products';
import { LoginService } from '../login/login/login.service';
import { Options } from '../check-out/check-out/options';

@Injectable()
export class ProductCartService {  
  wishListCount: number;
  cartCount: number;
  items: Products[] = [];
  localCartData: Products[] = [];
  checkProduct: Products[] = [];
  
  constructor(@Inject(LOCAL_STORAGE) private localStorage: any, private http:Http,  private loginService:LoginService) { }
  /** add cart data into localstorage*/
  addProductInLocalStorage(product:Products)
  {
     product.productInUserCartFlag = true;
     if( this.localStorage.getItem('cartData') )
     {
      this.items = JSON.parse( this.localStorage.getItem('cartData'))
      this.items.push(product); 
      this.localStorage.setItem('cartData', JSON.stringify(this.items));
      this.items = this.loadAllCartFromLocalStorage();
      return true; 
     }
     else
      return false;
  }

  /** get / display cart data from localstorage  */
  loadAllCartFromLocalStorage()
  {
    if( this.localStorage.getItem('cartData') )
    {
      return JSON.parse(this.localStorage.getItem('cartData'));
    }
  }

  /** Check cart data is already present into localstorage */
  checkProductIsAlreadyInLocalStorage(product:Products)
  {
    if(  this.localStorage.getItem('cartData') )
    {
      this.checkProduct = JSON.parse( this.localStorage.getItem('cartData'))
      for (let i = 0; i < this.checkProduct.length; i++) 
      {
        if (this.checkProduct[i].modelId == product.modelId) 
        {
          return true;
        }
      }
    }
    return false;
  }

  /** check cart data (localstorage) is empty or not  */
  checkLocalStroageIsEmpty()
  {
    if( this.localStorage.getItem('cartData') )
    {
      this.localCartData = JSON.parse( this.localStorage.getItem('cartData'))
      if(this.localCartData === null  || this.localCartData.length == 0 )
      {
        return true;
      }
    }
    return false;
  }

  /** Remove / delete product from cart (localstorage) */
  removeItemFromLocalCart(deleteProduct: Products)
  {
    if( this.localStorage.getItem('cartData') )
    {
      this.items = JSON.parse( this.localStorage.getItem('cartData'))
      for (let i = 0; i < this.items.length; i++) 
      {
        if (this.items[i].modelId == deleteProduct.modelId) 
        {
          this.items.splice(i,1)
        }
      }
      this.localStorage.setItem('cartData', JSON.stringify(this.items));
    }
  }

  /** Remove / delete product from cart (database)  */
  removeCartFromDatabase(cartId)
  {
    let headers = new Headers({
        'authorization': 'Bearer' + this.loginService.getToken(),
        'content-type': 'application/json'
    });   
    let options = new RequestOptions({headers: headers});
    return this.http.delete( AllServices.removeCartFromDatabaseUrl + '?id=' + cartId, options)
      .map(success => success.status);
  }
  
  removeWishlistFromDatabase(customerId,rentTransactionId,modelId){
    let headers = new Headers({
      'authorization': 'Bearer' + this.loginService.getToken(),
      'content-type': 'application/json'
    });   
    let options = new RequestOptions({headers: headers});
    return this.http.delete( AllServices.removeWishlistFromDatabaseUrl + '/' + customerId + '/' + rentTransactionId + '/' + modelId, options)
      .map(success => success.status);
  }
  /** get payumoney response */
  checkPaymentResponse(tid){
     let headers = new Headers({
        'authorization': 'Bearer' + this.loginService.getToken(),
        'content-type': 'application/json'
      });
       let options = new RequestOptions({headers: headers});
      return this.http.post(AllServices.ip + "/payumoney/paymentResponse",options)  
      .map(success => success.status);
  }
  /** Remove orderd data from checkout page */
  removePlaceOrderedDataFromCart(id){
    let headers = new Headers({
       'authorization': 'Bearer' + this.loginService.getToken(),
       'content-type': 'application/json'
     });
     let options = new RequestOptions({headers: headers});
      return this.http.delete( AllServices.removePlaceOrderedDataFromCartUrl+"?id="+id, options)
     .map(res => res.json);
  }
  /** Add cart data (localstorage / after login) into database */
  addCartDataToDatabase (data){
    let headers = new Headers({
      'authorization': 'Bearer' + this.loginService.getToken(),
      'content-type': 'application/json'
    });
    let options = new RequestOptions({headers: headers});
    return this.http.post( AllServices.addCartDataToDatabaseUrl,data ,options).map(res => res.json());
  }
  /** place order - checkout page */
  placeOrder(data){
      let headers = new Headers({
        'authorization': 'Bearer' + this.loginService.getToken(),
        'content-type': 'application/json'
      });
    let options = new RequestOptions({headers: headers});
    return this.http.post( AllServices.placeOrderUrl,data ,options).map(res => res.json());
  }
  /** generate payment hash */
  paymentHash(data){
      let headers = new Headers({
        'authorization': 'Bearer' + this.loginService.getToken(),
        'content-type': 'application/json'
      });
    let options = new RequestOptions({headers: headers});
    return this.http.post( AllServices.paymentHashUrl,data ,options).map(res => res.json());
  }
  /** pass payment data to payumoney */
  paymenturl(data:Options){
   let headers = new Headers({'Authorization':'Bearer C+DgKzkuheHIRzdjQjGKk7j/jryIxHtbHBPdQ7AbWWM='});
   let amount = parseFloat(data.amount).toFixed(1);
   let options =(
   {
     "firstname": data.firstname,
     "amount": amount,
     "productinfo": data.productinfo,
     "email": data.email,
     "phone":  data.phone,
     "key":  data.key,
     "txnid":  data.txnid,
     "hash": data.hash,
     "surl":  data.surl,
     "furl": data.furl,
     "service_provider": data.service_provider
   }); 
    return this.post( AllServices.paymenturl,options)
  }
  /** create DOM function for payumoney */
  post(path: string, params: any) {
     const form = document.createElement("form");
     form.setAttribute("method", "post");
     form.setAttribute("action", path);
     for (const key in params) 
     {
         if (params.hasOwnProperty(key)) 
         {
             const hiddenField = document.createElement("input");
             hiddenField.setAttribute("type", "hidden");
             hiddenField.setAttribute("name", key);
             hiddenField.setAttribute("value", params[key]);
             form.appendChild(hiddenField);
         }
     }
     document.body.appendChild(form);
     form.submit();
  }
  /** Get all cart data by customer */
  loadAllCartDataByCustomerId(id){
      let headers = new Headers({
        'authorization': 'Bearer' + this.loginService.getToken(),
        'content-type': 'application/json'
      });
     let options = new RequestOptions({headers: headers});
      return this.http.get( AllServices.loadAllCartDataByCustomerIdUrl+"?id="+id , options).map(res => res.json());
  }
  /** Get all cart data by customer */
  loadAllWishlistDataByCustomerId(id){
    let headers = new Headers({
      'authorization': 'Bearer' + this.loginService.getToken(),
      'content-type': 'application/json'
    });
   let options = new RequestOptions({headers: headers});
    return this.http.get( AllServices.loadAllWishlistDataByCustomerIdUrl+"?id="+id , options).map(res => res.json());
  }
  /**Get all order data by customer  in checkout page */
  loadAllOrderDataByCustomerId(id){
      let headers = new Headers({
        'authorization': 'Bearer' + this.loginService.getToken(),
        'content-type': 'application/json'
      });
     let options = new RequestOptions({headers: headers});
      return this.http.get( AllServices.loadAllOrderDataByCustomerIdUrl+"?id="+id , options).map(res => res.json());
  }
  /** get cart data count */
  cartItemCount(customerId,cartType){
    let headers = new Headers({
        'authorization': 'Bearer' + this.loginService.getToken(),
        'content-type': 'application/json'
    });
    let options = new RequestOptions({headers: headers});
    return this.http.get( AllServices.cartItemCountUrl+"/"+customerId+"/"+cartType , options).map(res => res.json());
  } 
  /** add / remove quantity in database */
  addOrRemoveQuantityInDatabase(cartId,opertion){
      let headers = new Headers({
        'authorization': 'Bearer' + this.loginService.getToken(),
        'content-type': 'application/json'
      });
      let options = new RequestOptions({headers: headers});
       return this.http.put( AllServices.addOrRemoveQuantityInDatabaseUrl+"?id="+cartId+"&operation="+opertion, null, options)
      .map(res => res.json);
  }
  /** get coupon details - check valid or not */
  getCouponDetails(couponcode){
    let headers = new Headers({
      'authorization': 'Bearer' + this.loginService.getToken(),
      'content-type': 'application/json'
    });
    let options = new RequestOptions({headers: headers});
    return this.http.get( AllServices.couponCodeUrl+"?couponCode="+couponcode , options).map(res => res.json());  
  } 
   /** load all customer address - checkout page and myaccount page */
  checkDocumentVerification(id){
    let headers = new Headers({
        'authorization': 'Bearer' + this.loginService.getToken(),
        'content-type': 'application/json'
    });
    let options = new RequestOptions({headers: headers});
    return this.http.get( AllServices.checkUserDocumentVerification+"?id="+id , options).map(res => res.json());
  }

  countCartItems()
  {
    this.cartCount = 0;
    if( this.localStorage.getItem('cartData') )
    {
      this.items = JSON.parse( this.localStorage.getItem('cartData'))
      if( this.items != null  )
      {
        this.items.forEach(product => 
        {
          if(product.cartType == "CART")
          {
            ++this.cartCount;
          }
        })
      }
    }
    return this.cartCount;
  }

  countWithListItems()
  {
    this.wishListCount =0;
    if( this.localStorage.getItem('cartData') )
    {
      this.items = JSON.parse( this.localStorage.getItem('cartData'))
      if(  this.items != null  )
      {
        this.items.forEach(product => 
        {
          if(product.cartType == "WISHLIST")
          {
            ++this.wishListCount;
          }
        })
      }
    }
    return this.wishListCount;
  } 

  moveDataToWishlistOrCart(cartId,cartType)
  {
    let headers = new Headers({
      'authorization': 'Bearer' + this.loginService.getToken(),
      'content-type': 'application/json'
    });
    let options = new RequestOptions({headers: headers});
    return this.http.put( AllServices.moveDataToWishlistOrCart +cartId+"/"+cartType, options)
    .map(res => res.json);
  }   
}
