export class ErrorStatus {
  constructor( public status: number,
                public errorMessage : string,
            ) { }
} 