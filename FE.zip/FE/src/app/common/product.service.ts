import { AllServices } from './allservices.services';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { error } from 'selenium-webdriver';
import { AppError} from './app-error';
import 'rxjs/add/operator/catch';
import { HttpHeaders } from '@angular/common/http';
import { LoginService } from '../login/login/login.service';

@Injectable()
export class ProductService 
{
  public levelId : number;
  collectionName : string; 

  constructor( private http:Http,private loginService: LoginService) { }
  
  private headers = new Headers(
  {
    'authorization': 'Bearer' + this.loginService.getToken(),
    'content-type': 'application/json'
  });
  
  options = new RequestOptions({headers: this.headers});
  
  private multipartheaders = new Headers(
  {
    'authorization': 'Bearer' + this.loginService.getToken()
  });
  
  multiPartOptions = new RequestOptions({headers: this.multipartheaders});

  // Fetch all products 
  getAllProducts(sortBy,customerId) 
  {
    return this.http.get( AllServices.allproductsurl+'?sortBy='+sortBy+'&userId='+customerId).map(res => res.json());
  }

  //Get All Feature Products  - Latest Products
  getFeatureProducts(customerId)
  {
    return this.http.get( AllServices.allFeatureProductData+'?userId='+customerId).map(res => res.json());
  }
  
  //Get Product Browser
  getRelatedProduct(id,customerId) 
  {
    return this.http.get( AllServices.relatedproductsburl+'?id='+id+'&userId='+customerId).map(res => res.json());
  }

  //get stock and check product booking dates
  getDiscountandStockonBookingValues(modelId,rentTransactionId,bookingFrom,bookingTo,levelOneId)
  {
    let object =
    ({
        "modelId":modelId,
        "rentTransactionId":rentTransactionId,
        "bookingFromDate":bookingFrom,
        "bookingToDate":bookingTo,
        "levelName":"levelOne",
        "levelId":levelOneId
    }); 
    //console.log(JSON.stringify(object));
    return this.http.post( AllServices.getDiscountandStockonBookingValues,object).map(res => res.json());
  }

  //Get Offer Data
  loadOfferData( transactionId )
  {
    return this.http.get( AllServices.loadOfferDataUrl+'?transactionId='+transactionId)
    .catch(
      (error:Response)=>{
      if (error.status === 404) {
            return Observable.throw ( new AppError(error));
          }
        }
      )
    .map((response: Response) =>  response.json())
  }

  private extractData(res: Response) 
  {
    let body = res.json();
    return body || [];
  }

  //Handling Errors
  private handleError (error: any) 
  {
    let errMsg = (error.message) ? error.message :
    error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    return Observable.throw(errMsg);
  }
  
  //Get All Filter Data
  allProductfilterData(id,name)
  {
    return this.http.get( AllServices.allProductfilterDataUrl +name+"/fetchFilters" +'?id='+id)
    .map((response:Response) => response.json());
  }

  //Get Selected Filter Data
  onSelectfilterData(data, sortBy,customerId)
  {
    let headers = new Headers({
      'content-type': 'application/json'
    });   
    let options = new RequestOptions({headers: headers});
    console.log(AllServices.onSelectfilterDataUrl+"?sortBy="+sortBy+'&userId='+customerId)
    return this.http.post( AllServices.onSelectfilterDataUrl+"?sortBy="+sortBy+'&userId='+customerId,data,options)
    .map((response:Response) => response.json());
  }

  //Get Product Data with Sorting (asc or desc)
  loadLevelItemData(id, name, sortBy, customerId)
  {
    return this.http.get( AllServices.loadLevelItemDataUrl+"/"+name+"/fetchRentableModels" +'?id='+id+ "&" +'sortBy='+sortBy+'&userId='+customerId)
    .catch(
        (error:Response)=>{
          if (error.status === 404) {
            return Observable.throw ( new AppError(error));
          }
        }
    )
    .map((response: Response) => {
      return  response.json() ; 
    }); 
  }

  //Get Product Images
  getAllProductImages (productId) 
  {
    return this.http.get( AllServices.getAllProductImagesUrl+'?id='+productId)
    .toPromise()
    .then(this.extractData)
    .catch(this.handleError);
  }

  //Get Product Details by Id
  getProductDetailsById(productId, transactionId,customerId)
  {
    return this.http.get( AllServices.getProductDetailsByIdUrl+'?id='+productId +"&transactionId="+ transactionId+"&userId="+customerId)
    .toPromise()
    .then(this.extractData)
    .catch(this.handleError); 
  } 

  /** get all product filters and specifications (product details) */
  getModelFilterById(productId, transactionId)
  {
    return this.http.get( AllServices.getModelFilterByIdUrl+'?id='+productId+"&transactionId="+transactionId)
    .map((response: Response) => 
    {
      return  response.json() ; 
    }); 
  }  

}