import { AllServices } from './allservices.services';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { error } from 'selenium-webdriver';
import { AppError} from './app-error';
import 'rxjs/add/operator/catch';
import { HttpHeaders } from '@angular/common/http';

@Injectable()
export class RegistartionService {
  public levelId : number;
  collectionName : string; 
  constructor( private http:Http,) { }
  
  //Register Customer
  registerCust(data){
    let headers = new Headers ({});
    return this.http.post( AllServices.createCustomer,data 
    ).map((response: Response) =>  response.json());
  }
  //Register Customer
  UpdateUserLegalDoc(customerid,formdata){
    return this.http.post( AllServices.updateUserLegalDoc+"?id="+customerid,formdata
    ).map((response: Response) =>  response.json());
  }
  //Get Customer Name 
  getByUsername(username: string): Observable<any> {
    return this.http.get( AllServices.getUserName+'?username='+username)
    .map(res => res.json());
  } 

  //check mobile number
  isMobileExits(mobilenumber){
    //console.log(AllServices.isMobileExits+'/'+mobilenumber);
    return this.http.get( AllServices.isMobileExits+'/'+mobilenumber)
    .map(res => res.json());
  }
}