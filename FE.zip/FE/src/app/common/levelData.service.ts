import { AllServices } from './allservices.services';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { error } from 'selenium-webdriver';
import { AppError} from './app-error';
import 'rxjs/add/operator/catch';
import { HttpHeaders } from '@angular/common/http';

@Injectable()
export class LevelDataService {
  public levelId : number;
  collectionName : string; 
  constructor(private http:Http,) { }
 
  //Get All Level One Data
  getLevelOneAll() 
  {
    return this.http.get( AllServices.getLevelOneAllUrl).map(res => res.json());
  }
  //Get All Level Two By Level One Id
  getLevelTwoAllById(levelOneId) {
    return this.http.get( AllServices.getLevelTwoAllByIdUrl + "?id=" + levelOneId)
    .map(res => res.json());
  }
  //Get All Level Three By Level Two Id
  getLevelThreeAllById(levelTwoId) {
    return this.http.get( AllServices.getLevelThreeAllByIdUrl + "?id=" + levelTwoId)
    .map(res => res.json());
  }
  //Get All Level Four By Level Three Id
  getLevelFourAllById(levelThreeId) {
    return this.http.get( AllServices.getLevelFourAllByIdUrl + "?id=" + levelThreeId)
    .map(res => res.json());
  }
  //Get All Level Two Data
  getLevelTwoAll() {
    return this.http.get( AllServices.getLevelTwoAllUrl)
    .map(res => res.json());
  }
  //Get All Level Three Data
  getLevelThreeAll() {
    return this.http.get( AllServices.getLevelThreeAllUrl)
    .map(res => res.json());
  }
  //Get All Level Four Data
  getLevelFourAll() {
    return this.http.get( AllServices.getLevelFourAllUrl)
    .map(res => res.json());
  }  
}