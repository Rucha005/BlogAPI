import { AllServices } from './allservices.services';
import { Injectable } from '@angular/core';
import { Http,  Headers,RequestOptions,Response } from '@angular/http';
import { LoginService } from '../login/login/login.service';


@Injectable()
export class AddressService {
  
  constructor(private http:Http,  private loginService:LoginService) { }

  //Add new Customer address
  addAddress(data,userid){
    let headers = new Headers({
      'authorization': 'Bearer' + this.loginService.getToken(),
      'content-type': 'application/json'
    });  
    let options = new RequestOptions({headers: headers});
      return this.http.post( AllServices.createAddress+'?id='+userid, data ,options 
      ).map((response: Response) =>  response.json());
  }
  //Add new Customer address
  deleteUserAddress(addressid){
    let headers = new Headers({
      'authorization': 'Bearer' + this.loginService.getToken(),
      'content-type': 'application/json'
    });  
    let options = new RequestOptions({headers: headers});
      return this.http.delete( AllServices.deleteAddress+'?id='+addressid,options 
      ).map((response: Response) =>  response.json());
  }
   /** load all customer address - checkout page and myaccount page */
   loadUserAddress(id){
    let headers = new Headers({
        'authorization': 'Bearer' + this.loginService.getToken(),
        'content-type': 'application/json'
    });
    let options = new RequestOptions({headers: headers});
    return this.http.get( AllServices.loadCartUserAddressUrl+"?id="+id , options).map(res => res.json());
}
}