export class Products {
	constructor( 
				 public modelId: number,
				 public modelName: string,
				 public imageURL: string,
				 public rentPerDay: number,
				 public cartType:string,
				 public isInWishlistFlag:boolean,
				 public deposit: number,
        	 	 public percentageOffer: number,
				 public modelDescription: string,
				 public durationUnit: number,
				 public bookingFromDate: string,
				 public bookingToDate: string,
				 public days: number,
				 public deliverydate: string,
				 public pickupdate: string,
         		 public rentTransactionId: number,
				 public productQuantity:number,
				 public orderedQuantity:number,
				 public deliveredQuantity:number,
				 public additionalCharges:number,
				 public subtotal: number,
				 public totalRent: number, 
         		 public priceAfterOffer: number,
         		 public rentCartId:number,
         		 public userId:number,
         		 public productInUserCartFlag:boolean,
         		 public netSaleableStock:number,
				 public shippingPrice:number,
				 public netRentableStock: number,  
				 public rentCartItemOffers: rentCartItemOffers[],
				 public levelName : string,
				 public levelId: any,
				 public availableFlag:boolean,
				 public levelOneId:any,
				 public levelTwoId:any,
				 public levelThreeId:any,
				 public levelFourId:any

       ) { }
} 
export class rentCartItemOffers{
  constructor( 
		 public cartItemOffersId: number,
		 public offerId : any,
         public offerName: string,
         public percentageOffer: number,
		 public offerDescription: string,
		 public groupNo:number  
       ) { } 
}