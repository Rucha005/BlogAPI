export class Filterdropdown {
					public filterId :number;
	                public filterName : string;
	                public filterDescription: string;
	                public filterDataType : string;
	                public filterDisplayType : string;
	                public filterContainer : string;
	                public displayOrder : number;
	                public visible: boolean;
	                public filterDropdown: any;
}