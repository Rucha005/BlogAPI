import { Component, OnInit,Input,ViewChild, ElementRef, AfterViewInit,Output,EventEmitter,HostListener,Renderer,ViewChildren, Renderer2, PLATFORM_ID, Inject} from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators, FormControl, AbstractControl } from '@angular/forms';
import { RouterModule, ActivatedRoute, Router,NavigationEnd} from '@angular/router';
import { Location, isPlatformBrowser } from '@angular/common';
import { ErrorStatus } from '../../common/ErrorStatus';
import { ProductService } from '../../common/product.service';
import { RegistartionService } from '../../common/registartion.service';
import { ProductCartService } from '../../common/product-cart.service';
import { LoginService } from '../../login/login/login.service';
import { WINDOW } from '@ng-toolkit/universal';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent
{
  cartitems: any;
  customerId: any;
  pagedItems: any[];
  errorStatus:ErrorStatus;
  v = 4;
  cardsize = "260px";
  productPadding:any ;
  show: boolean = false; 
  
  constructor(private renderer : Renderer2,private route: ActivatedRoute,private router: Router,private cartService:ProductCartService,
    private productService : ProductService,private loginService :LoginService,private spinnerService: Ng4LoadingSpinnerService,
    private registrationservice: RegistartionService, @Inject(PLATFORM_ID) private platformId,@Inject(WINDOW) private window) 
  {
     /** Responsive latest product slider */
     if( isPlatformBrowser(this.platformId))
     {
      if(this.window.innerWidth <= 600)
      {
        this.v =1;
        this.productPadding = "0px";
        this.cardsize = "280px";
      }
      else 
      if(this.window.innerWidth <= 800)
      {
        this.v =3;
        this.productPadding = "0px";
      }
      else
      {
        this.v =4;
        this.productPadding ="0px";
      }
    }
  }
  
  ngOnInit()
  {
    //new change
    this.show = false;

    if(this.loginService.isLoggedIn())
    {
      this.getByUsername();
    }
    else
    {
      this.getLatestProductsWithoutLogin();
    }
  }

  /** display latest / feature products */
  ngAfterViewInit()
  {
    /** focus on perticular div when back to page */
    if(localStorage.getItem('collectiontype') != null)
    {
      let collectiontype = localStorage.getItem('collectiontype');
      //this.renderer.selectRootElement('#'+collectiontype).focus()
      localStorage.removeItem('collectiontype');
    } 
    localStorage.removeItem('levelOne');  
    localStorage.removeItem('levelFour');
    
   
  }

  /** get customer name after login */
  getByUsername() 
  {
   let username;
   const currentUser = JSON.parse(localStorage.getItem('currentUser'));
   if (currentUser) 
   {
     username = currentUser.username;
     this.spinnerService.show();   
     this.registrationservice.getByUsername(username).subscribe(c => 
     {
       this.spinnerService.hide();   
       this.customerId = c.userId;
      this.getLatestProductsWithLogin(); 
     },
     (error)=>
     {
       this.spinnerService.hide();   
     });
   }
  } 

  getLatestProductsWithLogin()
  {
    this.productService.getFeatureProducts(this.customerId)
    .subscribe(s => 
    {
      this.pagedItems = s;
    },(error)=>{})
  }

  getLatestProductsWithoutLogin()
  {
    this.productService.getFeatureProducts(0).subscribe(s => 
    {
      this.pagedItems = s;
      this.cartitems = this.cartService.loadAllCartFromLocalStorage();
      for(let p=0; p<this.pagedItems.length; p++ )
      {
        if(this.cartitems)
        {
          for(let product=0; product< this.cartitems.length;product++)
          {
            if(this.cartitems[product].modelId == this.pagedItems[p].modelId)
            {
              this.pagedItems[p].cartType = this.cartitems[product].cartType;
            }
          }
        } 
      }
    },
    (error)=>
    {      
    })
  }

  /** focus or scroll down on rent rather than buy div */ 
  focusKeywordsInput()
  {
    document.getElementById('rentmore').scrollIntoView()
  } 
 
  /** slider configuration for brands*/
  config1: SwiperOptions = 
  {
    pagination: '.swiper-pagination',
    paginationClickable: true,
    autoplay: 4000,
    watchSlidesProgress: true,
    watchSlidesVisibility: true,
    loop: true,
    loopAdditionalSlides: 2,
    loopedSlides: 2,
    slidesPerView: 4,
  };

  /** slider configuration for partners*/
  config2: SwiperOptions = 
  {
    pagination: '.swiper-pagination',
    paginationClickable: true,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    slidesPerView: 3,
  };

  /** navigate to product browser page when click on types of collection and some categories */
  saveCollection(levelone,id,returntype)
  {
    localStorage.setItem('collectiontype',returntype);
    this.router.navigate(['/productlist/', levelone ,id]);
  }
  
  /** navigate to product details page */
  navigate(event,modelId,rentTransactionId,levelOneId)
  {
    localStorage.removeItem('leveloneid');
    localStorage.setItem('levelOne',levelOneId);
    this.router.navigate(['/product/', modelId ,rentTransactionId])
    event.preventDefault();
    event.stopPropagation();
  }       
}
