export class LevelOneData {

	constructor( 
				 public levelOneId: number,
			     public levelOneName :string,
        		 public levelOneDescription : string,
				 public defaultImageLink:string,
				 public displayOrder,
				 public levelTwo: LevelTwoData[]
       			) { }
} 

export class LevelTwoData {
	constructor(
				 public levelTwoId: number,
		         public levelTwoName : string,
		         public levelTwoDescription:  string,
                 public defaultImageLink:  string,
                 public displayOrder:  string,
                 public levelThree: LevelThreeData[]
	    
	){}
    
}
export class LevelThreeData {
	constructor(
				 public levelThreeId: number,
		         public levelThreeName : string,
		         public levelThreeDescription:  string,
                 public defaultImageLink:  string,
                 public displayOrder:  string,
                 public levelFour: LevelFourData[]
	    
	){}
    
}
export class LevelFourData {
	constructor(
				 public levelFourId: number,
		         public levelFourName : string,
		         public levelFourDescription:  string,
                 public defaultImageLink:  string,
                 public displayOrder:  string,
                
	    
	){}
    
}