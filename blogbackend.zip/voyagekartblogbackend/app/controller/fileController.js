const uploadFolder = __basedir + '/uploads/';
const fs = require('fs');

var onlyPath = require('path').dirname('/uploads/');

 
exports.uploadFile = (req, res) => {
	res.send('File uploaded successfully! -> filename = ' + req.file.filename);
}
