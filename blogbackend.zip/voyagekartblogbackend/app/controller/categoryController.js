'use strict';

var Category = require('../model/categoryModel.js');

//list all categories
exports.listAllCategory = function (req, res) {
    Category.getAllCategory(function (err, category) {
        console.log('controller')
        if (err)
            res.send(err);
        console.log('res', category);
        res.send(category);
    });
};

//create new category
exports.createCategory = function (req, res) {
    var newcategory = new Category(req.body);
    console.log('category is: ' + newcategory);
    //handles null error 
    if (!newcategory.name || !newcategory.description) {
        res.status(400).send({ error: true, message: 'Please provide name/description' });
    }
    else {
        Category.createCategory(newcategory, function (err, category) {
            if (err)
                res.send(err);
            res.json({category, message:'category saved successfully'});
        });
    }
};

//read category by id
exports.readCategory = function (req, res) {
    Category.getCategoryById(req.params.categoryid, function (err, category) {
        if (err)
            res.send(err);
        res.json(category);
    });
};

//update category by id
exports.updateCategory = function (req, res) {
    Category.updateById(req.params.categoryid, new Category(req.body), function (err, category) {
        if (err)
            res.send(err);
        res.json(category);
    });
};

//delete category by id
exports.deleteCategory = function (req, res) {
    Category.remove(req.params.categoryid, function (err, category) {
        if (err)
            res.send(err);
        res.json({ message: 'Category successfully deleted' });
    });
};

//check category exist
exports.checkCategoryExist = function (req, res) {
    Category.checkCategoryExist(req.params.name, function (err, category) {
        if (err)
            res.send(err);
        res.json(category);
    });
};