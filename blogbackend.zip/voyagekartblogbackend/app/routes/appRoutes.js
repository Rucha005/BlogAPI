'use strict';

module.exports = function (app) {
  var category = require('../controller/categoryController');
  // category Routes
  app.route('/category/create')
    .post(category.createCategory)
  app.route('/category')
    .get(category.listAllCategory)
  app.route('/category/:categoryid')
    .get(category.readCategory)  
  app.route('/category/update/:categoryid')
    .put(category.updateCategory)  
  app.route('/category/delete/:categoryid')
    .delete(category.deleteCategory)   
  app.route('/category/checkexist/:name')
    .get(category.checkCategoryExist)

  var blog = require('../controller/blogController');
  // blog Routes
  app.route('/blog/create')
    .post(blog.createBlog)
  app.route('/blog')
    .get(blog.listAllBlogs)
  app.route('/blog/:blogid')
    .get(blog.readBlog)  
  app.route('/blog/update/:blogid')
    .put(blog.updateBlog)  
  app.route('/blog/delete/:blogid')
    .delete(blog.deleteBlog)  
  app.route('/blog/getcategory/:categoryid')
    .get(blog.getCategoryName)
  app.route('/blog/getcategorydata/:categoryid')
    .get(blog.getCategoryData)
  app.route('/blog/featureblog/:blogid')
    .get(blog.getFeaturedBlogData)
};