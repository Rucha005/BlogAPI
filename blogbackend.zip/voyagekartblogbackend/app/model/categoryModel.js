'user strict';
var sql = require('../db.js');

//Category object constructor
var Category = function (category) {
    this.name = category.name;
    this.description = category.description; 
};

// create new category
Category.createCategory = function createCategory(newCategory, result) {
    sql.query("INSERT INTO category set ?", newCategory, function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        }
        else {
            console.log(res.insertId);
            result(null, res.insertId);
        }
    });
};

//get all category 
Category.getAllCategory = function getAllCategory(result) {
    sql.query("Select * from category", function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {
            console.log('categories : ', res);

            result(null, res);
        }
    });
};

// get category data by id
Category.getCategoryById = function getCategoryById(categoryid, result) {
    sql.query("Select * from category where categoryid = ? ", categoryid, function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        }
        else {
            result(null, res);

        }
    });
};

//update category
Category.updateById = function (categoryid, category, result) {
    sql.query("UPDATE category SET name = ? , description = ? WHERE categoryid = ?", [category.name,category.description, categoryid], 
    function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {
            result(null, res);
        }
    });
};

// delete category
Category.remove = function (categoryid, result) {
    sql.query("DELETE FROM category WHERE categoryid = ?", [categoryid], function (err, res) {

        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {

            result(null, res);
        }
    });
};

//check category exist 
Category.checkCategoryExist = function checkCategoryExist(name, result) {
    console.log("in category exist model...");
    sql.query("Select name from category where name = ? ", name, function (err, res) {
        console.log("result lenth in model: " + res.length)
        if (res.length > 0) { 
            console.log('here in if..');
            result(null, true);
        }else{
            result(err, false);
        }
    });
};

module.exports = Category;